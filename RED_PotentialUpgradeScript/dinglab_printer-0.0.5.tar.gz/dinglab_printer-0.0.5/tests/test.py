import dinglab_printer as m

assert m.__version__ == "0.0.5"
assert m.add(1, 2) == 3
assert m.subtract(1, 2) == -1
