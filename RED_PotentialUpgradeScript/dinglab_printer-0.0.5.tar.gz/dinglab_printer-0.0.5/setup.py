# Available at setup time due to pyproject.toml
from pybind11.setup_helpers import Pybind11Extension, build_ext
from pybind11.setup_helpers import ParallelCompile, naive_recompile

ParallelCompile("NPY_NUM_BUILD_JOBS", needs_recompile=naive_recompile).install()

from setuptools import setup, find_packages

__version__ = "0.0.5"

# The main interface is through Pybind11Extension.
# * You can add cxx_std=11/14/17, and then build_ext can be removed.
# * You can set include_pybind11=false to add the include directory yourself,
#   say from a submodule.
#
# Note:
#   Sort input source files if you glob sources to ensure bit-for-bit
#   reproducible builds (https://github.com/pybind/python_example/pull/53)

ext_modules = [
    Pybind11Extension(
        "dinglab_printer",
        ["src/dinglab_printer/main.cpp", "src/dinglab_printer/wrapper.cpp"],
        include_dirs=["src/dinglab_printer/includes"],
        library_dirs=["src/dinglab_printer/libs"],
        libraries=['KPDLP660', 'KPMSP430'],
        # Example: passing in the version to the compiled code
        define_macros=[("VERSION_INFO", __version__)],
        # include_package_data=True,
    ),
]

setup(
    name="dinglab_printer",
    version=__version__,
    author="Edwin Clement",
    author_email="edwinclement08@gmail.com",
    url="https://github.com/edwinclement08/dinglab_printer",
    description="Python Package to Interact with UV Resin Printer",
    long_description="",
    ext_modules=ext_modules,
    extras_require={"test": "pytest"},
    # Currently, build_ext only provides an optional "highest supported C++
    # level" feature, but in the future it may provide more features.
    cmdclass={"build_ext": build_ext},
    zip_safe=False,
    python_requires=">=3.7",
    packages=['dinglab_printer'],
    package_dir={"dinglab_printer": "src/dinglab_printer"},
    package_data={'dinglab_printer': ['includes/*', 'libs/*']},
    data_files=[('lib/site-packages', ['src/dinglab_printer/BSL430.dll',
                'src/dinglab_printer/hidapi.dll',
                'src/dinglab_printer/KPDLP660.dll',
                'src/dinglab_printer/KPMSP430.dll',
                'src/dinglab_printer/shellstyle.dll',
                'src/dinglab_printer/vfcompat.dll', ])]
)
