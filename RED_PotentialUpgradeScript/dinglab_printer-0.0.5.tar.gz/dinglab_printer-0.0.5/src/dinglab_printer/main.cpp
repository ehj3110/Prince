#include <pybind11/pybind11.h>
#include <iostream>
#include <Windows.h>

#include "kpdlp660.h"
#include "kpmsp430.h"
#include "main.hpp"

#define MSLEEP(x)        Sleep(x);

using namespace std;

int Controller::add(int i, int j) {
    cout << "testing the cpp bindings" <<endl;
    return i + j + 2;
}

Controller::Controller() {
    cout << "Hello world" <<endl;
}

Controller::~Controller() {
}

ControllerResult Controller::check_connection() {
    struct ControllerResult result;
    int i = 0;
    do {
          uCDev.USB_Open();
    } while (!uCDev.USB_IsConnected() && i++ < 10);

    if (!uCDev.USB_IsConnected()) {
        result.success = false;
        result.message = "Can't connect to micro-controller";
        cerr << result.message << endl;
        return result;
    }

    i = 0;
    do {
          DLPDev.USB_Open();
    } while (!DLPDev.USB_IsConnected() && i++ < 10);

    if (!DLPDev.USB_IsConnected()) {
        result.success = false;
        result.message = "Can't connect to micro-controller";
        cerr << result.message << endl;

        return result;
    }
   
   result.success = true;
   result.message = "Connected Successfully";
   
   return result;
}

ControllerResult Controller::initialize() {
    // Check power state of projector before sending any other commands
    struct ControllerResult result;
    result.success = false;

    unsigned char powerMode = 99;
    if (DLPDev.LCR_GetPowerMode(&powerMode) == 0)
    {
        switch (powerMode)
        {
        case 0:
            result.message = "Projector is still in RESET...exiting for now";
			return result;

        case 1:
            result.message = "Projector is still in STANDBY...exiting for now"; 
			return result;

        case 2:
            // The Success case
            result.message = "Projector is in READY...";
            break;

        case 3:
            result.message = "Projector is still in COOLING...exiting for now";
			return result;

        case 4:
            result.message = "Projector is still in BOOTUP...exiting for now";
			return result;

        case 5:
            result.message = "Projector is still in POWERUP...exiting for now";
			return result;

        default:
            result.message = "Projector is in an Unknown State...exiting.";
			return result;
        }
    } else {
        result.message = "Projector connection problem ... exiting.";
		return result;
    }

    DLPDev.LCR_SetXPRmode(1);		// Make sure we are in manual actuator mode (only one supported)
    DLPDev.LCR_SetXPR_DAC(0);		// Set nominal starting actuator position
    cout << "Initialize actuator and move to starting position" << endl;

	unsigned int major, minor, build;
	unsigned char fanSel = 1;
	unsigned char fanPWM = 50;
	unsigned char fanMode = 1;

	unsigned int minTemp16, lowTemp16, maxTemp16;

	uCDev.MSP_GetVersion(&major, &minor, &build); // Checking the MSP firmware version to determine if the MSP is capable of fan control. 

	//DISCLAIMER: Firmware/hardware mismatch can cause this function not to work. 
	// Rev C or later Jackboard and firmware v2.0.0 are required for the fan controls to work.
	if(major >= 2)
	{
		cout << "Reading current fan Temperature limits." << endl;
		if(uCDev.MSP_GetFanTempLimits(&minTemp16, &lowTemp16, &maxTemp16) < 0)
		{
			cout << "Unable to set fan duty cycle." << endl;
		}
		cout << "  -- Low Temp Bin = " << (float)minTemp16/10 << "C, Med Temp Bin = " << (float)lowTemp16/10  << "C, Hi Temp Bin = " << (float)maxTemp16/10 << "C." << endl;

		cout << "Setting fan #" << (int)fanSel << " to " << (int)fanPWM << "% PWM and mode " << (int)fanMode << "." << endl;
		if(uCDev.MSP_SetFanPWM(fanSel, fanMode, fanPWM) < 0)
		{
			cout << "Unable to set fan duty cycle." << endl;
		}

		cout << "  -- Reading back the fan settings to confirm." << endl;
		if(uCDev.MSP_GetFanPWM(fanSel, &fanMode, &fanPWM) < 0)
		{
			cout << "Unable to get fan duty cycle." << endl;
		} else {
			cout << "  -- Fan #" << (int)fanSel << " is currently in mode " << (int)fanMode << ", set to a PWM of " << (int)fanPWM << "%." << endl;
		}
	} else {									  // If correct Jackboard firmware/hardware version is not present, use DLP controller for fan control
		cout << "Setting fan PWM to 50% duty cycle." << endl;
		if(DLPDev.LCR_SetFanPWM(1, 50) < 0)
		{
			cout << "Unable to set fan duty cycle." << endl;
		}
	}

    result.success = true;
    return result;
}

ControllerResult Controller::get_amplitude() {
    ControllerResult cr;
    unsigned int AmpReg;

    AmpReg = 0;
    cout << "Reading the current LED amplitude setting from projector" << endl;

    if(uCDev.MSP_GetLEDAmplitude(&AmpReg) < 0)
    {
        cr.message = "Unable to get LED Driver Amplitude";
        cr.success = false;
        cerr << cr.message << endl;
        return cr;
    }

    cout << "Current LED amplitude = " << AmpReg << endl;
    cr.int_value = AmpReg;
    cr.success = true;

    return cr;
}

ControllerResult Controller::set_amplitude(float Amplitude) {
    ControllerResult cr;
    unsigned int AmpReg;

    // Set LED drive to desired level [W]
    if (Amplitude > 1) {
        cout << "Setting Brightness above 1 W at " << Amplitude << ". Make sure you know what you are doing!" << endl;
    }

    AmpReg = (unsigned int) (Amplitude * 0x1f4);

    cout << "Setting LED amplitude to " << AmpReg << endl;
    if(uCDev.MSP_SetLEDAmplitude(AmpReg) < 0)
    {
        cr.message = "Unable to set LED Driver Amplitude";
        cr.success = false;

        cerr << cr.message << endl;

        return cr;
    }
    cr.success = true;
    return cr;
}

ControllerResult Controller::show_splash(float Amplitude, int seconds) {
    ControllerResult cr;

    cr = set_amplitude(Amplitude);
    if (!cr.getSuccess()) {
        return cr;
    }

    cout << "Switching projector display mode to Splash Screen" << endl;
    DLPDev.LCR_ChangeProjectorMode(DLPDev.DISP_SPLASH);
    MSLEEP(5000); // longer delay required after mode changes

    // Enable the LED (constant on)
    if(DLPDev.LCR_LEDWithTimer(true, 0) < 0)
    {
        cr.message = "Unable to enable the LED";
        cr.success = false;
        cerr << cr.message << endl;
        return cr;
    }

    cout << "Waiting " << seconds << " seconds" << endl;
    MSLEEP(seconds * 1000); // using software delay this time

    // Turn off the LED
    if(DLPDev.LCR_LEDWithTimer(false, 0) < 0)
    {
        cr.message = "Unable to disable the LED";
        cr.success = false;
        cerr << cr.message << endl;
        return cr;
    }

    cout << "-\n---- Splash image Test Completed \n-" << endl;
}

ControllerResult Controller::change_mode_to_displayport() {
    ControllerResult cr;
    unsigned char s0, s1, s2, s3;	// Status bytes
    cr.success = false;
    cout << "Selecting DisplayPort input" << endl;
    DLPDev.LCR_ChangeProjectorMode(DLPDev.DISP_DP);  // switch projector to Display Port mode

    cout << "Polling Status after mode change until phase/freq lock is complete ..." << endl;
    if (DLPDev.LCR_GetErrorStatusWord(&s0, &s1, &s2, &s3) < 0)
    {
        cr.message = "Unable to get Error Status from DLP controller";
        cerr << cr.getMessage() << endl;
        return cr;
    } else {
		cout << " Error Status words: " << (unsigned int)s0 << " : " << (unsigned int)s1 << " : " << (unsigned int)s2 << " : " << (unsigned int)s3 << endl;
        
    }

    if ((s0 & 0x01) != 0)  {                                    // Sequence Error
        cr.message = " *** Sequencer Error detected ***";
        cerr << cr.getMessage() << endl;
    }

    if ((s0 & 0x02) != 0) {                                    // Pixel Clock Out of Range
        cr.message = " *** Pixel Clock out of range ***";
        cerr << cr.getMessage() << endl;
    }

    if ((s0 & 0x04) != 0) {                                    // VSync Lost or Out of Range
        cr.message = " *** Vsync lost or out of range ***";
        cerr << cr.getMessage() << endl;
    }


	int pollNum = 50;		// Max Repeat polling status to see when we are locked
	do {	
        // After mode change to another source, check status to be sure
        // the input is valid before continuing.
        if (DLPDev.LCR_GetSystemStatusWord(&s0, &s1, &s2, &s3) < 0)
        {
            cr.message = "Unable to get Error Status from DLP controller";
            cerr << cr.getMessage() << endl;
            return cr;
        } else {
            cout << " System Status words: " << (unsigned int)s0 << " : " << (unsigned int)s1 << " : " << (unsigned int)s2 << " : " << (unsigned int)s3 << endl;
        }
        if ((s0 & 0x04) != 0x04)  {                                    
            cr.message = "*** Sequencer Frane Rate is NOT Locked ***";
            cerr << cr.getMessage() << endl;
        }

        if ((s0 & 0x08) != 0x08) {                                    
            cr.message = "  *** Sequencer NOT Phase Locked ***";
            cerr << cr.getMessage() << endl;
        }

        if ((s0 & 0x16) != 0x16) {                                    
            cr.message = "  *** Sequencer NOT Frequency Locked ***";
            cerr << cr.getMessage() << endl;
        }
        MSLEEP(500);		// 0.5 sec delay between status polls
	} while (--pollNum && (s1 != 0x1C));

	if(pollNum < 1) {
        cr.message = "Unable to get valid status within alloted time.  *** \n  Ignoring for now to continue testing";
        cerr << cr.message << endl;
    }
	else {
        cout << "Shifting actuator to maximum position" << endl;
        DLPDev.LCR_SetXPR_DAC(252);

        cr.success = true;
        cr.message = "System Status indicates Phase and Frequency successfully locked on input";
	    cout << cr.message << endl;
        return cr;
    }
}

ControllerResult Controller::led_activate() {
    ControllerResult result;
	
    cout << "Shifting actuator to maximum position, turning on LED" << endl;
    DLPDev.LCR_SetXPR_DAC(252);

    if(DLPDev.LCR_LEDWithTimer(true, 0) < 0)
    {
        result.message = "Unable to enable the LED";
        result.success = false;
        cerr << result.message << endl;

        return result;
    }

    result.success = true;

    return result;
}

ControllerResult Controller::led_deactivate() {
    ControllerResult result;
	
    if(DLPDev.LCR_LEDWithTimer(false, 0) < 0)
    {
        result.message = "Unable to disable the LED";
        result.success = false;
        cerr << result.message << endl;

        return result;
    }

    result.success = true;

    return result;
}

// ControllerResult Controller::expose_led(float seconds) {
//     unsigned int origLEDOnTime, newLEDOnTime;
//     float desiredExposure = seconds;
//     ControllerResult result;
	
//     cout << "Shifting actuator to maximum position, turning on LED" << endl;
//     DLPDev.LCR_SetXPR_DAC(252);

//     // Check LED driver for current total On-Time for reference later
//     if(uCDev.MSP_GetLEDOnTime(&origLEDOnTime) < 0)
//     {
//         result.message = "Unable to get LED Driver On Time";
//         result.success = false;
//         cerr << result.message << endl;

//         return result;
//     }

//     // Turn on the LED for 2 seconds
//     if(DLPDev.LCR_LEDWithTimer(true, desiredExposure) < 0)
//     {
//         result.message = "Unable to enable the LED with internal timer";
//         result.success = false;
//         cerr << result.message << endl;

//         return result;
//     }

//     cout << "Waiting for Exposure to complete (at least 2 seconds)" << endl;
//     MSLEEP((int)seconds * 1000 + 500); // software delay until after expose time (> 2 seconds)

//     // Check LED Driver timer to determine actual exposure duration
//     if(uCDev.MSP_GetLEDOnTime(&newLEDOnTime) < 0)
//     {
//         result.message = "Unable to get LED Driver On Time(2)";
//         result.success = false;
//         cerr << result.message << endl;

//         return result;
//     }

//     result.success = true;
//     result.int_value = newLEDOnTime - origLEDOnTime;

//     return result;
// }

void Controller::disconnect() {
    cout << "Turn off actuator (move to neutral position)." << endl;

    // turn off actuator
    if (DLPDev.LCR_SetXPR_DAC(128) < 0)
    {
        cout << "Unable to set XPR DAC in manual mode" << endl;
    }
    // Close USB connections
    cout << "Disconnect from projector and exit." << endl;

    DLPDev.USB_Close();
    uCDev.USB_Close();

}


int Controller::test() {
    ControllerResult result = check_connection();
    if (result.success == false) { 
        cout << "Error connecting to the projector: " << result.message << endl;
        return -1;
    }

    result = initialize();
    if (result.success == false) { 
        cout << "Error Initializing" << result.message << endl;
        return -2;
    }


    ////////////////////////////////////////////////////////////////////
    // Example 1: Display Splash image
    ////////////////////////////////////////////////////////////////////
    show_splash(0.5, 5);

    ////////////////////////////////////////////////////////////////////
    // Example 2: Controlled Exposure from HDMI/Display-Port input
    ////////////////////////////////////////////////////////////////////
    unsigned int AmpReg;
    float Amplitude;

    ////////////////////////////////////////////////////////////////////
    // Example 3: Internal Test Pattern Generator control
    ////////////////////////////////////////////////////////////////////

    cout << "Reset actuator to starting position" << endl;
    DLPDev.LCR_SetXPR_DAC(0);

    // Set LED drive to desired level [W]
    Amplitude = 0.5;
    AmpReg = (unsigned int) (Amplitude * 0x1f4);

    if(uCDev.MSP_SetLEDAmplitude(AmpReg) < 0)
    {
        cout << "Unable to set LED Driver Amplitude" << endl;
        return -1;
    }

    cout << "Switch to Test Pattern mode" << endl;
    DLPDev.LCR_ChangeProjectorMode(DLPDev.DISP_TPG);  // switch projector to test pattern mode
    MSLEEP(5000); // longer delay required after mode changes

    // Enable the LED (constant on)
    if(DLPDev.LCR_LEDWithTimer(true, 0) < 0)
    {
        cout << "Unable to enable the LED" << endl;
        return -1;
    }

    cout << "Selecting various Test Patterns" << endl;
    DLPDev.LCR_SetTPGSelect(DLPDev.H_RAMP); // set test pattern- horizontal ramp
    cout << " - Displaying Horizontal ramps ..." << endl;
    MSLEEP(3000); // short pause

    DLPDev.LCR_SetTPGSelect(DLPDev.V_RAMP); // set test pattern- vertical ramp
    cout << " - Displaying Vertical ramps ..." << endl;
    MSLEEP(3000); // short pause

    DLPDev.LCR_SetTPGSelect(DLPDev.CHECKER); // set test pattern- checkerboard
    cout << " - Displaying Checkerboard ..." << endl;
    MSLEEP(3000); // short pause

    // Turn off the LED
    if(DLPDev.LCR_LEDWithTimer(false, 0) < 0)
    {
        cout << "Unable to disable the LED" << endl;
        return -1;
    }

    cout << "Turn off actuator (move to neutral position)." << endl;

    // turn off actuator
    if (DLPDev.LCR_SetXPR_DAC(128) < 0)
    {
        cout << "Unable to set XPR DAC in manual mode" << endl;
    }

    cout << "-\n---- Internal TPG Control Test Completed \n-" << endl;

    // Close USB connections
    cout << "Disconnect from projector and exit." << endl;

    DLPDev.USB_Close();
    uCDev.USB_Close();

    return 0;
}
