#include <pybind11/pybind11.h>
#include <main.hpp>

namespace py = pybind11;

#define STRINGIFY(x) #x
#define MACRO_STRINGIFY(x) STRINGIFY(x)

PYBIND11_MODULE(dinglab_printer, m) {
    m.doc() = R"pbdoc(
        Pybind11 example plugin
        -----------------------

        .. currentmodule:: dinglab_printer

        .. autosummary::
           :toctree: _generate

           add
           subtract
    )pbdoc";

    py::class_<Controller>(m, "Controller")
        .def(py::init<>())
        .def("add", &Controller::add)
        .def("test", &Controller::test)
        .def("check_connection", &Controller::check_connection)
        .def("initialize", &Controller::initialize)
        .def("show_splash", &Controller::show_splash)
        .def("get_amplitude", &Controller::get_amplitude)
        .def("set_amplitude", &Controller::set_amplitude)
        .def("led_activate", &Controller::led_activate)
        .def("led_deactivate", &Controller::led_deactivate)
        // .def("expose_led", &Controller::expose_led)
        .def("change_mode_to_displayport", &Controller::change_mode_to_displayport)
        .def("disconnect", &Controller::disconnect)
        ;
    
    py::class_<ControllerResult>(m, "ControllerResult")
        .def("getMessage", &ControllerResult::getMessage)
        .def("getFloatValue", &ControllerResult::getFloatValue)
        .def("getIntValue", &ControllerResult::getIntValue)
        .def("getSuccess", &ControllerResult::getSuccess);


#ifdef VERSION_INFO
    m.attr("__version__") = MACRO_STRINGIFY(VERSION_INFO);
#else
    m.attr("__version__") = "dev";
#endif
}