#include "kpdlp660.h"
#include "kpmsp430.h"
#include <string>

#if !defined(CONTROLLER_MAIN_H)
#define CONTROLLER_MAIN_H

struct ControllerResult {
    bool success;
    string message;
    int int_value;
    float float_value;

    const string &getMessage() const { return message; }
    const bool &getSuccess() const { return success; }
    const int &getIntValue() const { return int_value; }
    const float &getFloatValue() const { return float_value; }
};


class Controller {
    private:
    KPMSP430 uCDev;
    KPDLP660 DLPDev;

    public:

    Controller();
    ~Controller();

    int add(int i, int j);
    int test();

    ControllerResult check_connection();
    ControllerResult initialize();
    ControllerResult change_mode_to_displayport();

    ControllerResult get_amplitude();
    ControllerResult set_amplitude(float Amplitude);
    
    ControllerResult expose_led(float seconds);

    ControllerResult led_deactivate();
    ControllerResult led_activate();
    ControllerResult show_splash(float Amplitude, int seconds);
    void disconnect();
};

#endif // CONTROLLER_MAIN_H


