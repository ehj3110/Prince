dinglab_printer
==============

A project built with PyBind11 for interfacing with the following DLLs to work with the resin 3D Micro-Printer

This was written and tested with Python 3.11.8; this should work with >3.9. If facing problems, contact the author(@edwinclement08)

- `pip install ./dinglab_printer`

Building
---------

```
# install the build tool
python3 -m pip install --upgrade build
python3 -m build
```

The wheel file will be generated in dist/*

Building the documentation
--------------------------

Documentation for the example project is generated using Sphinx. Sphinx has the
ability to automatically inspect the signatures and documentation strings in
the extension module to generate beautiful documentation in a variety formats.
The following command generates HTML-based reference documentation; for other
formats please refer to the Sphinx manual:

 - `cd dinglab_printer/docs`
 - `make html`


Test call
---------

```python
import dinglab_printer
```

==================
- cpp changes
    - Sub Second show image
        - Keep the light on all the time
            light on fn
            light off fn
    - Make stop button work
        - Add an interrupt mechanism
    - Remove multithreading (not needed)

- Python GUI changes
    - add textbox for setting the black interval time
    - continous mode/stepwise mode
    - set focal position using text box
    - Make stop button work
- red <- printer name