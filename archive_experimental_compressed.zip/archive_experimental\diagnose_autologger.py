#!/usr/bin/env python3
"""
Autologger Diagnostic Script
Run this to check if autologger is working properly
"""

def diagnose_autologger_setup():
    print("=== Autologger Diagnostic ===")
    
    # Check for required files
    import os
    
    print("\n1. Checking file structure...")
    
    # Check if AutomatedLayerLogger exists
    if os.path.exists("AutomatedLayerLogger.py"):
        print("✓ AutomatedLayerLogger.py found")
    else:
        print("✗ AutomatedLayerLogger.py missing")
        return
    
    # Check if SensorDataWindow exists
    if os.path.exists("SensorDataWindow.py"):
        print("✓ SensorDataWindow.py found")
    else:
        print("✗ SensorDataWindow.py missing")
        return
    
    # Check if PositionLogger exists
    if os.path.exists("PositionLogger.py"):
        print("✓ PositionLogger.py found")
    else:
        print("✗ PositionLogger.py missing")
        return
    
    print("\n2. Testing imports...")
    
    try:
        from AutomatedLayerLogger import LayerLogger
        print("✓ AutomatedLayerLogger import successful")
    except Exception as e:
        print(f"✗ AutomatedLayerLogger import failed: {e}")
        return
    
    try:
        from PositionLogger import PositionLogger
        print("✓ PositionLogger import successful")
    except Exception as e:
        print(f"✗ PositionLogger import failed: {e}")
        return
    
    print("\n3. Creating test logging window file...")
    
    # Create a test logging windows file
    test_windows_file = "test_logging_windows.csv"
    try:
        with open(test_windows_file, 'w', newline='') as f:
            import csv
            writer = csv.writer(f)
            writer.writerow(["StartLayer", "EndLayer"])
            writer.writerow([2, 3])  # Test window: layers 2-3
        print(f"✓ Created test logging windows file: {test_windows_file}")
    except Exception as e:
        print(f"✗ Failed to create test logging windows file: {e}")
        return
    
    print("\n4. Testing LayerLogger configuration...")
    
    # Test LayerLogger configuration
    def mock_status_callback(message, error=False, warning=False):
        prefix = "ERROR: " if error else ("WARNING: " if warning else "INFO: ")
        print(f"  {prefix}{message}")
    
    try:
        logger = LayerLogger(mock_status_callback, None)
        print("✓ LayerLogger created successfully")
        
        # Test configuration
        test_log_dir = "test_logs"
        os.makedirs(test_log_dir, exist_ok=True)
        
        success = logger.configure_run(1, test_log_dir, test_windows_file)
        if success:
            print("✓ LayerLogger configuration successful")
        else:
            print("✗ LayerLogger configuration failed")
            
    except Exception as e:
        print(f"✗ LayerLogger test failed: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n5. Cleanup...")
    
    # Clean up test files
    try:
        if os.path.exists(test_windows_file):
            os.remove(test_windows_file)
        if os.path.exists("test_logs"):
            import shutil
            shutil.rmtree("test_logs")
        print("✓ Test files cleaned up")
    except Exception as e:
        print(f"Warning: Cleanup error: {e}")
    
    print("\n=== Diagnostic Complete ===")
    print("\nIf all checks passed, the autologger should work.")
    print("If there were failures, check the error messages above.")
    print("\nTo debug during actual printing, look for these messages:")
    print("- 'AutomatedLayerLogger: Attempting to start recording for L2-L3...'")
    print("- 'Automated recording started for L2-L3 to autolog_L2-L3.csv'")
    print("- 'Recording started to: ...autolog_L2-L3.csv (Automated)'")

def check_recent_logs():
    print("\n=== Checking Recent Log Files ===")
    
    import os
    import glob
    from datetime import datetime, timedelta
    
    # Look for recent autolog files
    patterns = [
        "**/autolog_*.csv",
        "**/Printing_Logs/**/*.csv",
        "autolog_*.csv"
    ]
    
    recent_files = []
    cutoff_time = datetime.now() - timedelta(hours=2)  # Files from last 2 hours
    
    for pattern in patterns:
        for file_path in glob.glob(pattern, recursive=True):
            try:
                file_time = datetime.fromtimestamp(os.path.getmtime(file_path))
                if file_time > cutoff_time:
                    recent_files.append((file_path, file_time))
            except:
                continue
    
    if recent_files:
        print("Recent autolog files found:")
        for file_path, file_time in sorted(recent_files, key=lambda x: x[1], reverse=True):
            file_size = os.path.getsize(file_path)
            print(f"  {file_path} - {file_time.strftime('%H:%M:%S')} - {file_size} bytes")
    else:
        print("No recent autolog files found")

if __name__ == "__main__":
    diagnose_autologger_setup()
    check_recent_logs()
    
    print("\n=== Manual Check Instructions ===")
    print("1. Run your print and watch console for autologger messages")
    print("2. Check if 'logging_windows.csv' is created in your print directory")
    print("3. Verify the logging windows are defined correctly (StartLayer,EndLayer)")
    print("4. Look for 'AutomatedLayerLogger configured via SensorDataWindow' message")
    print("5. Check if autolog_LX-LY.csv files are created during print")
