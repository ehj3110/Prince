"""
Test Enhanced Analysis with Baseline Correction
==============================================

This script tests the corrected baseline analysis on the real data,
focusing on proper peel initiation and completion detection.
"""

import numpy as np
from enhanced_adhesion_metrics import EnhancedAdhesionAnalyzer

def test_corrected_analysis():
    """Test the enhanced analysis with baseline correction on real data"""
    
    # Read the real data
    times = []
    forces = []
    positions = []
    
    with open('example_data.csv', 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:  # Skip header
            parts = line.strip().split(',')
            times.append(float(parts[0]))
            positions.append(float(parts[1]))
            forces.append(float(parts[2]))
    
    times = np.array(times)
    forces = np.array(forces)
    positions = np.array(positions)
    
    print("Enhanced Analysis with Baseline Correction")
    print("=" * 50)
    
    # Create analyzer
    analyzer = EnhancedAdhesionAnalyzer(smoothing_sigma=0.2, noise_threshold=0.003)
    
    # Analyze three peel events
    peel_windows = [
        (10, 16, "Layer 1"),   # Around 12s
        (30, 38, "Layer 2"),   # Around 34s  
        (52, 60, "Layer 3")    # Around 56s
    ]
    
    for start_time, end_time, label in peel_windows:
        print(f"\n{label} Analysis ({start_time}-{end_time}s):")
        print("-" * 40)
        
        # Extract window data
        mask = (times >= start_time) & (times <= end_time)
        window_times = times[mask]
        window_forces = forces[mask]
        window_positions = positions[mask]
        
        if len(window_times) < 10:
            print("Insufficient data in window")
            continue
        
        # Run enhanced analysis
        results = analyzer.analyze_peel_data(window_times, window_positions, window_forces)
        
        # Display key results
        print(f"Baseline correction applied: {results.get('baseline_corrected', False)}")
        print(f"True baseline: {results.get('true_baseline', 'N/A'):.6f} N")
        
        print(f"\nPeel Initiation (force crosses baseline):")
        print(f"  Time: {results.get('peel_initiation_time', 'N/A'):.3f} s")
        print(f"  Position: {results.get('peel_initiation_position', 'N/A'):.4f} mm")
        print(f"  Force: {results.get('peel_initiation_force', 'N/A'):.6f} N")
        
        print(f"\nPeak Force:")
        print(f"  Time: {results.get('peak_force_time', 'N/A'):.3f} s")
        print(f"  Position: {results.get('peak_force_position', 'N/A'):.4f} mm")
        print(f"  Magnitude: {results.get('peak_force_magnitude', 'N/A'):.6f} N")
        
        print(f"\nPeel Completion (return to baseline):")
        print(f"  Time: {results.get('peel_completion_time', 'N/A'):.3f} s")
        print(f"  Position: {results.get('peel_completion_position', 'N/A'):.4f} mm")
        
        print(f"\nTiming Analysis:")
        print(f"  Time to peak: {results.get('time_to_peak_from_initiation', 'N/A'):.3f} s")
        print(f"  Peak to completion: {results.get('peak_to_completion_time', 'N/A'):.3f} s")
        print(f"  Total duration: {results.get('total_peel_duration', 'N/A'):.3f} s")
        
        print(f"\nWork Analysis (baseline corrected):")
        print(f"  Work of adhesion: {results.get('work_of_adhesion_mJ', 'N/A'):.4f} mJ")
        print(f"  Energy dissipation: {results.get('energy_dissipation_mJ', 'N/A'):.4f} mJ")
        
        # Check if quick drop is detected
        peak_to_completion = results.get('peak_to_completion_time', float('nan'))
        print(f"\nQuick sawtooth drop analysis:")
        print(f"  Peak to completion: {peak_to_completion:.3f} s")
        print(f"  Quick drop (<0.5s): {peak_to_completion < 0.5}")
        
        # Calculate expected start times based on user feedback
        expected_starts = {
            "Layer 1": 11.1,  # Close to movement start
            "Layer 2": 32.5,  # User specified
            "Layer 3": 55.0   # User specified
        }
        
        actual_start = start_time + results.get('peel_initiation_time', 0)
        expected_start = expected_starts.get(label, actual_start)
        start_difference = abs(actual_start - expected_start)
        
        print(f"\nValidation against expected timing:")
        print(f"  Expected peel start: {expected_start:.1f} s")
        print(f"  Detected peel start: {actual_start:.1f} s")
        print(f"  Difference: {start_difference:.1f} s")
        print(f"  Good detection (<1s diff): {start_difference < 1.0}")

    print(f"\n{'='*50}")
    print("Analysis Complete!")
    print("Key Improvements:")
    print("- Post-separation baseline correction")
    print("- Peel initiation when force crosses true baseline")
    print("- Completion when force returns to baseline")
    print("- Baseline-corrected work calculations")

if __name__ == "__main__":
    test_corrected_analysis()
