#!/usr/bin/env python3
"""
Test the improved timing detection against your specific observations:
- Layer 1 propagation should end at ~12.8 seconds
- Layer 2 propagation should end at ~34.1-34.2 seconds
- Baseline should be higher/more accurate
"""

import pandas as pd
import numpy as np
from enhanced_adhesion_metrics import EnhancedAdhesionMetrics

def test_improved_timing():
    print("Testing improved timing detection...")
    print("=" * 60)
    
    # Load the data
    try:
        df = pd.read_csv('autolog_L48-L50.csv')
        print(f"Loaded {len(df)} data points")
    except Exception as e:
        print(f"Error loading data: {e}")
        return
    
    # Extract the data
    times = df['Time'].values
    positions = df['Position'].values  
    force = df['Force'].values
    
    # Create analyzer with adjusted parameters for better detection
    analyzer = EnhancedAdhesionMetrics(noise_threshold=0.05)  # Slightly more sensitive
    
    # Analyze the full dataset
    print("\nFull Dataset Analysis:")
    print("-" * 30)
    
    results = analyzer.analyze_peel_event(times, positions, force)
    
    # Print key timing results
    print(f"True baseline detected: {results.get('true_baseline', 'N/A'):.3f}")
    print(f"Baseline correction applied: {results.get('baseline_corrected', False)}")
    print()
    
    # Print timing for all detected events
    if 'peel_initiation_time' in results:
        print(f"Peel initiation: {results['peel_initiation_time']:.1f}s")
    if 'peak_force_time' in results:
        print(f"Peak force: {results['peak_force_time']:.1f}s")
    if 'peel_completion_time' in results:
        print(f"Peel completion: {results['peel_completion_time']:.1f}s")
    
    print("\n" + "=" * 60)
    print("INDIVIDUAL LAYER ANALYSIS")
    print("=" * 60)
    
    # Analyze individual layers based on your observations
    layer_ranges = [
        ("Layer 1", 0, 800),      # ~0-24s (rough estimate)
        ("Layer 2", 800, 1600),   # ~24-48s  
        ("Layer 3", 1600, 2260)   # ~48-67s
    ]
    
    target_completions = {
        "Layer 1": 12.8,
        "Layer 2": 34.1,  # or 34.2
        "Layer 3": None   # Can't see the plot for this one
    }
    
    for layer_name, start_idx, end_idx in layer_ranges:
        print(f"\n{layer_name} Analysis:")
        print("-" * 30)
        
        # Extract layer data
        layer_times = times[start_idx:end_idx]
        layer_positions = positions[start_idx:end_idx]
        layer_force = force[start_idx:end_idx]
        
        if len(layer_times) < 10:
            print("Insufficient data for analysis")
            continue
        
        # Analyze this layer
        layer_results = analyzer.analyze_peel_event(layer_times, layer_positions, layer_force)
        
        # Print results
        baseline = layer_results.get('true_baseline', 'N/A')
        print(f"Baseline: {baseline:.3f}")
        
        initiation = layer_results.get('peel_initiation_time', 'N/A')
        peak = layer_results.get('peak_force_time', 'N/A')
        completion = layer_results.get('peel_completion_time', 'N/A')
        
        print(f"Initiation: {initiation:.1f}s")
        print(f"Peak: {peak:.1f}s") 
        print(f"Completion: {completion:.1f}s")
        
        # Check against target if available
        target = target_completions.get(layer_name)
        if target is not None and completion != 'N/A':
            absolute_completion = (layer_times[0] - times[0]) + completion
            error = abs(absolute_completion - target)
            print(f"Absolute completion time: {absolute_completion:.1f}s")
            print(f"Target completion: {target:.1f}s")
            print(f"Error: {error:.1f}s")
            
            if error < 0.5:
                print("✓ EXCELLENT timing accuracy!")
            elif error < 1.0:
                print("✓ Good timing accuracy")
            else:
                print("⚠ Timing needs improvement")
    
    print("\n" + "=" * 60)
    print("BASELINE ANALYSIS")
    print("=" * 60)
    
    # Check baseline quality across the dataset
    print("Checking baseline stability across layers...")
    
    # Check baseline in different regions
    regions = [
        ("Start", 0, 100),
        ("Mid-Layer 1", 300, 400),
        ("Between L1-L2", 700, 800),
        ("Mid-Layer 2", 1200, 1300),
        ("Between L2-L3", 1500, 1600),
        ("End", 2150, 2260)
    ]
    
    for region_name, start, end in regions:
        if end <= len(force):
            region_force = force[start:end]
            mean_force = np.mean(region_force)
            std_force = np.std(region_force)
            print(f"{region_name:12}: Mean={mean_force:.3f}, Std={std_force:.3f}")

if __name__ == "__main__":
    test_improved_timing()
