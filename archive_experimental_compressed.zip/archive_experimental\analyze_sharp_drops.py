"""
Find Quick Force Drops (True Sawtooth) in Peel Events
====================================================

This script looks for the rapid force drops that create the sawtooth pattern,
which should happen much faster than the overall peel event.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def find_sharp_force_drops():
    """Find the rapid force drops (sawtooth edges) within each peel event"""
    
    # Load data
    df = pd.read_csv('example_data.csv')
    time = df['Elapsed Time (s)'].values
    force = df['Force (N)'].values
    
    # Focus on narrow windows around the previously identified peaks
    peak_times = [12.478, 33.875, 56.251]  # From previous analysis
    
    print("Sharp Force Drop Analysis")
    print("=" * 50)
    
    drop_results = []
    
    for i, peak_time in enumerate(peak_times):
        layer_num = i + 1
        print(f"\nLayer {layer_num} - Sharp Drop Analysis:")
        print("-" * 35)
        
        # Create narrow window around peak (±2 seconds)
        window_size = 2.0
        start_time = peak_time - window_size
        end_time = peak_time + window_size
        
        mask = (time >= start_time) & (time <= end_time)
        t_window = time[mask]
        f_window = force[mask]
        
        if len(t_window) == 0:
            print("No data in window")
            continue
        
        # Find peak in this narrow window
        peak_idx = np.argmax(f_window)
        actual_peak_time = t_window[peak_idx]
        actual_peak_force = f_window[peak_idx]
        
        print(f"Peak: {actual_peak_force:.6f}N at {actual_peak_time:.3f}s")
        
        # Calculate high-resolution force gradient
        force_gradient = np.gradient(f_window, t_window)
        
        # Look for the steepest negative gradient AFTER the peak
        post_peak_mask = np.arange(len(t_window)) > peak_idx
        if np.sum(post_peak_mask) > 0:
            post_peak_gradient = force_gradient[post_peak_mask]
            post_peak_times = t_window[post_peak_mask]
            post_peak_forces = f_window[post_peak_mask]
            
            # Find steepest drop
            steepest_drop_idx = np.argmin(post_peak_gradient)
            steepest_drop_rate = post_peak_gradient[steepest_drop_idx]
            steepest_drop_time = post_peak_times[steepest_drop_idx]
            
            print(f"Steepest drop rate: {steepest_drop_rate:.3f} N/s at {steepest_drop_time:.3f}s")
            
            # Find start and end of rapid drop
            # Start: when gradient becomes significantly negative
            rapid_drop_threshold = steepest_drop_rate * 0.3  # 30% of steepest rate
            rapid_drop_start_candidates = np.where(post_peak_gradient < rapid_drop_threshold)[0]
            
            if len(rapid_drop_start_candidates) > 0:
                drop_start_idx = peak_idx + rapid_drop_start_candidates[0] + 1
                drop_start_time = t_window[drop_start_idx]
                drop_start_force = f_window[drop_start_idx]
                
                # End: when gradient returns to near zero
                gradient_recovery_threshold = steepest_drop_rate * 0.1  # 10% of steepest rate
                recovery_candidates = np.where(post_peak_gradient[rapid_drop_start_candidates[0]:] > gradient_recovery_threshold)[0]
                
                if len(recovery_candidates) > 0:
                    drop_end_idx = peak_idx + rapid_drop_start_candidates[0] + recovery_candidates[0] + 1
                    drop_end_time = t_window[drop_end_idx] if drop_end_idx < len(t_window) else t_window[-1]
                    drop_end_force = f_window[drop_end_idx] if drop_end_idx < len(f_window) else f_window[-1]
                else:
                    # Use a reasonable default if no clear recovery
                    drop_end_idx = min(drop_start_idx + 10, len(t_window) - 1)
                    drop_end_time = t_window[drop_end_idx]
                    drop_end_force = f_window[drop_end_idx]
                
                # Calculate sharp drop metrics
                sharp_drop_duration = drop_end_time - drop_start_time
                force_drop_amount = drop_start_force - drop_end_force
                
                print(f"Sharp drop start: {drop_start_time:.3f}s, Force: {drop_start_force:.6f}N")
                print(f"Sharp drop end: {drop_end_time:.3f}s, Force: {drop_end_force:.6f}N")
                print(f"Sharp drop duration: {sharp_drop_duration:.3f}s")
                print(f"Force drop amount: {force_drop_amount:.6f}N")
                print(f"Sharp drop < 0.5s: {sharp_drop_duration < 0.5}")
                
                # Calculate time from peak to start of sharp drop
                peak_to_drop_delay = drop_start_time - actual_peak_time
                print(f"Delay from peak to sharp drop: {peak_to_drop_delay:.3f}s")
                
                drop_results.append({
                    'layer': layer_num,
                    'peak_time': actual_peak_time,
                    'peak_force': actual_peak_force,
                    'drop_start_time': drop_start_time,
                    'drop_end_time': drop_end_time,
                    'sharp_drop_duration': sharp_drop_duration,
                    'force_drop_amount': force_drop_amount,
                    'steepest_drop_rate': steepest_drop_rate,
                    'peak_to_drop_delay': peak_to_drop_delay
                })
            else:
                print("No clear sharp drop detected")
        else:
            print("No post-peak data available")
    
    # Create visualization
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    for i, (result, ax) in enumerate(zip(drop_results, axes)):
        # Extract data for detailed view
        peak_time = result['peak_time']
        start_time = peak_time - 1.0  # ±1 second around peak
        end_time = peak_time + 1.0
        
        mask = (time >= start_time) & (time <= end_time)
        t_detail = time[mask]
        f_detail = force[mask]
        
        ax.plot(t_detail, f_detail, 'b-', linewidth=2, label='Force')
        ax.axvline(result['peak_time'], color='r', linestyle='--', label='Peak')
        ax.axvline(result['drop_start_time'], color='orange', linestyle='--', label='Drop Start')
        ax.axvline(result['drop_end_time'], color='purple', linestyle='--', label='Drop End')
        
        # Highlight the sharp drop region
        drop_mask = (t_detail >= result['drop_start_time']) & (t_detail <= result['drop_end_time'])
        if np.any(drop_mask):
            ax.fill_between(t_detail[drop_mask], f_detail[drop_mask], alpha=0.3, color='red', label='Sharp Drop')
        
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Force (N)')
        ax.set_title(f"Layer {result['layer']} Sharp Drop\nDuration: {result['sharp_drop_duration']:.3f}s")
        ax.grid(True, alpha=0.3)
        ax.legend()
    
    plt.tight_layout()
    plt.savefig('sharp_force_drops.png', dpi=150, bbox_inches='tight')
    plt.show()
    
    # Summary of sharp drops
    print("\n" + "=" * 50)
    print("SHARP DROP SUMMARY:")
    print("=" * 50)
    
    if drop_results:
        sharp_durations = [r['sharp_drop_duration'] for r in drop_results]
        print(f"Sharp drop durations: {[f'{d:.3f}s' for d in sharp_durations]}")
        print(f"Average sharp drop duration: {np.mean(sharp_durations):.3f}s")
        print(f"All sharp drops < 0.5s: {all(d < 0.5 for d in sharp_durations)}")
        print(f"Steepest drop rates: {[f'{r['steepest_drop_rate']:.2f} N/s' for r in drop_results]}")
    
    return drop_results

if __name__ == "__main__":
    results = find_sharp_force_drops()
