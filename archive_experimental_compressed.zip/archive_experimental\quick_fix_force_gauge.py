"""
Quick Fix Script for Force Gauge Issues

This script temporarily replaces ForceGaugeManager with DebugForceGaugeManager
to help diagnose the force gauge readout problem.

Run this if you're having issues with force gauge readings.
"""

import shutil
import os
import sys

def backup_and_replace():
    """Backup original and replace with debug version."""
    
    original_file = "ForceGaugeManager.py"
    debug_file = "DebugForceGaugeManager.py"
    backup_file = "ForceGaugeManager_BACKUP.py"
    
    try:
        # Check if files exist
        if not os.path.exists(original_file):
            print(f"❌ {original_file} not found in current directory")
            return False
            
        if not os.path.exists(debug_file):
            print(f"❌ {debug_file} not found in current directory")
            return False
        
        # Create backup if it doesn't exist
        if not os.path.exists(backup_file):
            print(f"📦 Creating backup: {backup_file}")
            shutil.copy2(original_file, backup_file)
        else:
            print(f"📦 Backup already exists: {backup_file}")
        
        # Replace the ForceGaugeManager class in SensorDataWindow.py
        sensor_window_file = "SensorDataWindow.py"
        if os.path.exists(sensor_window_file):
            print(f"🔧 Updating import in {sensor_window_file}")
            
            # Read the file
            with open(sensor_window_file, 'r') as f:
                content = f.read()
            
            # Replace the import
            old_import = "from ForceGaugeManager import ForceGaugeManager"
            new_import = "from DebugForceGaugeManager import DebugForceGaugeManager as ForceGaugeManager"
            
            if old_import in content:
                content = content.replace(old_import, new_import)
                
                # Write back
                with open(sensor_window_file, 'w') as f:
                    f.write(content)
                print(f"✅ Updated import in {sensor_window_file}")
            else:
                print(f"⚠️  Could not find import statement in {sensor_window_file}")
        
        print("✅ Quick fix applied successfully!")
        print("\n📋 What this does:")
        print("   - Uses DebugForceGaugeManager with extensive logging")
        print("   - Removes USBCoordinator dependency")
        print("   - Adds debug output to track issues")
        print("\n🔧 To test:")
        print("   1. Run your main application")
        print("   2. Open the sensor data window")
        print("   3. Try calibration")
        print("   4. Check the terminal for DEBUG messages")
        print("\n🔄 To restore original:")
        print("   Run this script with --restore flag")
        
        return True
        
    except Exception as e:
        print(f"❌ Error during replacement: {e}")
        return False

def restore_original():
    """Restore the original ForceGaugeManager."""
    
    original_file = "ForceGaugeManager.py" 
    backup_file = "ForceGaugeManager_BACKUP.py"
    sensor_window_file = "SensorDataWindow.py"
    
    try:
        if not os.path.exists(backup_file):
            print(f"❌ Backup file {backup_file} not found")
            return False
        
        # Restore original ForceGaugeManager
        print(f"🔄 Restoring {original_file} from backup")
        shutil.copy2(backup_file, original_file)
        
        # Restore SensorDataWindow import
        if os.path.exists(sensor_window_file):
            print(f"🔧 Restoring import in {sensor_window_file}")
            
            with open(sensor_window_file, 'r') as f:
                content = f.read()
            
            old_import = "from DebugForceGaugeManager import DebugForceGaugeManager as ForceGaugeManager"
            new_import = "from ForceGaugeManager import ForceGaugeManager"
            
            if old_import in content:
                content = content.replace(old_import, new_import)
                
                with open(sensor_window_file, 'w') as f:
                    f.write(content)
                print(f"✅ Restored import in {sensor_window_file}")
        
        print("✅ Original ForceGaugeManager restored!")
        return True
        
    except Exception as e:
        print(f"❌ Error during restore: {e}")
        return False

def main():
    print("="*60)
    print("FORCE GAUGE QUICK FIX SCRIPT")
    print("="*60)
    
    if len(sys.argv) > 1 and sys.argv[1] == "--restore":
        success = restore_original()
    else:
        success = backup_and_replace()
    
    if success:
        print("\n🎉 Operation completed successfully!")
    else:
        print("\n❌ Operation failed. Check the error messages above.")
    
    print("="*60)

if __name__ == "__main__":
    main()
