"""
Test script to verify ForceGaugeManager fixes without requiring Phidget hardware.
This helps validate the code structure and threading logic.
"""

import sys
import os
import threading
import time
import queue
import tkinter as tk
from tkinter import ttk

# Add the current directory to Python path to import our modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Mock Phidget classes for testing without hardware
class MockVoltageRatioInput:
    def __init__(self):
        self.attached = False
        self.data_interval = 25
        self.channel = 0
        
    def setChannel(self, channel):
        self.channel = channel
        
    def setOnVoltageRatioChangeHandler(self, handler):
        self.voltage_ratio_handler = handler
        
    def setOnAttachHandler(self, handler):
        self.attach_handler = handler
        
    def setOnDetachHandler(self, handler):
        self.detach_handler = handler
        
    def setOnErrorHandler(self, handler):
        self.error_handler = handler
        
    def openWaitForAttachment(self, timeout):
        self.attached = True
        if hasattr(self, 'attach_handler'):
            self.attach_handler(self)
            
    def setDataInterval(self, interval):
        self.data_interval = interval
        
    def getAttached(self):
        return self.attached
        
    def close(self):
        self.attached = False

class MockPhidgetException(Exception):
    def __init__(self, code, description, details):
        self.code = code
        self.description = description
        self.details = details
        super().__init__(f"{code}: {description} - {details}")

# Mock the Phidget imports
import sys
from unittest.mock import MagicMock

# Create mock modules
mock_phidget = MagicMock()
mock_phidget.Phidget = MagicMock()
mock_phidget.Devices = MagicMock()
mock_phidget.Devices.VoltageRatioInput = MagicMock()
mock_phidget.Devices.VoltageRatioInput.VoltageRatioInput = MockVoltageRatioInput
mock_phidget.PhidgetException = MagicMock()
mock_phidget.PhidgetException.PhidgetException = MockPhidgetException
mock_phidget.ErrorCode = MagicMock()
mock_phidget.ErrorCode.ErrorCode = MagicMock()
mock_phidget.BridgeGain = MagicMock()

# Add mocks to sys.modules
sys.modules['Phidget22'] = mock_phidget
sys.modules['Phidget22.Phidget'] = mock_phidget.Phidget
sys.modules['Phidget22.Devices'] = mock_phidget.Devices
sys.modules['Phidget22.Devices.VoltageRatioInput'] = mock_phidget.Devices.VoltageRatioInput
sys.modules['Phidget22.Devices.VoltageInput'] = mock_phidget.Devices.VoltageInput
sys.modules['Phidget22.Net'] = mock_phidget.Net
sys.modules['Phidget22.PhidgetException'] = mock_phidget.PhidgetException
sys.modules['Phidget22.ErrorCode'] = mock_phidget.ErrorCode
sys.modules['Phidget22.BridgeGain'] = mock_phidget.BridgeGain

# Now we can import our module
try:
    from ForceGaugeManager import ForceGaugeManager
    print("✓ ForceGaugeManager imported successfully")
except ImportError as e:
    print(f"✗ Failed to import ForceGaugeManager: {e}")
    sys.exit(1)

def test_force_gauge_manager():
    """Test ForceGaugeManager initialization and basic functionality"""
    print("\n=== Testing ForceGaugeManager ===")
    
    # Create a simple tkinter window for testing
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    
    # Create mock labels
    gain_label = ttk.Label(root, text="Gain: N/A")
    offset_label = ttk.Label(root, text="Offset: N/A")
    force_status_label = ttk.Label(root, text="Force: N/A")
    large_force_readout_label = ttk.Label(root, text="Force: N/A")
    
    # Create output queue
    output_queue = queue.Queue()
    
    try:
        # Test initialization
        print("Testing ForceGaugeManager initialization...")
        force_manager = ForceGaugeManager(
            gain_label=gain_label,
            offset_label=offset_label,
            force_status_label=force_status_label,
            large_force_readout_label=large_force_readout_label,
            output_force_queue=output_queue,
            parent_window=root,
            sensor_window_ref=None
        )
        print("✓ ForceGaugeManager initialized successfully")
        
        # Test DLP-friendly mode
        print("Testing DLP-friendly mode...")
        force_manager.enable_dlp_friendly_mode()
        print("✓ DLP-friendly mode enabled")
        
        force_manager.disable_dlp_friendly_mode()
        print("✓ DLP-friendly mode disabled")
        
        # Test data rate limits
        print("Testing data rate limits...")
        force_manager.set_data_rate_limit(100)
        print("✓ Data rate limit set")
        
        # Test resource usage monitoring
        print("Testing resource usage monitoring...")
        usage = force_manager.get_current_resource_usage()
        print(f"✓ Resource usage: {usage}")
        
        # Test thread management
        print("Testing thread management...")
        print(f"Critical thread running: {force_manager._critical_thread_running}")
        print(f"Critical thread alive: {force_manager._critical_data_thread.is_alive() if force_manager._critical_data_thread else 'None'}")
        print(f"GUI thread alive: {force_manager._gui_update_thread.is_alive() if force_manager._gui_update_thread else 'None'}")
        
        # Wait a moment for threads to process
        time.sleep(1)
        
        # Test cleanup
        print("Testing cleanup...")
        force_manager.close_phidget()
        print("✓ Cleanup completed")
        
        return True
        
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        root.destroy()

def test_dlp_coordinator():
    """Test DLP coordinator functionality"""
    print("\n=== Testing DLP Coordinator ===")
    
    try:
        from dlp_phidget_coordinator import DLPPhidgetCoordinator, DLPOperationContext
        print("✓ DLP coordinator imported successfully")
        
        # Test with None force manager (should handle gracefully)
        coordinator = DLPPhidgetCoordinator(None)
        coordinator.prepare_for_dlp_operation()
        coordinator.restore_after_dlp_operation()
        status = coordinator.get_status()
        print(f"✓ Coordinator status: {status}")
        
        # Test context manager
        with DLPOperationContext():
            print("✓ DLP operation context entered and exited successfully")
        
        return True
        
    except Exception as e:
        print(f"✗ DLP coordinator test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("ForceGaugeManager Fix Verification")
    print("==================================")
    
    success = True
    
    # Test ForceGaugeManager
    if not test_force_gauge_manager():
        success = False
    
    # Test DLP coordinator
    if not test_dlp_coordinator():
        success = False
    
    print("\n=== Test Results ===")
    if success:
        print("✓ All tests passed! The fixes should work correctly.")
        print("\nYou can now:")
        print("1. Open the sensor panel without AttributeError")
        print("2. Use DLP operations with automatic resource coordination")
        print("3. Monitor resource usage and adjust data rates as needed")
    else:
        print("✗ Some tests failed. Please check the error messages above.")
    
    return success

if __name__ == "__main__":
    main()
