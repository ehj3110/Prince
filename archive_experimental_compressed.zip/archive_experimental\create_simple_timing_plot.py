#!/usr/bin/env python3
"""
Simple Improved Timing Plot
===========================

Creates a focused plot showing the enhanced timing detection results.
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from enhanced_adhesion_metrics import EnhancedAdhesionAnalyzer

def create_simple_timing_plot():
    """Create a simple but comprehensive timing validation plot"""
    
    print("Creating improved timing validation plot...")
    
    # Load data
    times, forces, positions = [], [], []
    
    with open('example_data.csv', 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:  # Skip header
            parts = line.strip().split(',')
            if len(parts) >= 3:
                times.append(float(parts[0]))
                positions.append(float(parts[1]))
                forces.append(float(parts[2]))
    
    times = np.array(times)
    forces = np.array(forces)
    positions = np.array(positions)
    
    # Create analyzer
    analyzer = EnhancedAdhesionAnalyzer(noise_threshold=0.04)
    
    # Analyze individual layers
    layer_data = []
    
    # Layer 1
    l1_times = times[0:800]
    l1_forces = forces[0:800]
    l1_positions = positions[0:800]
    try:
        l1_results = analyzer.analyze_peel_data(l1_times, l1_positions, l1_forces)
        l1_completion = l1_results.get('peel_completion_time', None)
        l1_baseline = l1_results.get('true_baseline', None)
        if l1_completion is not None:
            abs_l1_completion = (l1_times[0] - times[0]) + l1_completion
            layer_data.append(('Layer 1', abs_l1_completion, 12.8, l1_baseline, 'red'))
    except:
        pass
    
    # Layer 2
    l2_times = times[800:1600]
    l2_forces = forces[800:1600]
    l2_positions = positions[800:1600]
    try:
        l2_results = analyzer.analyze_peel_data(l2_times, l2_positions, l2_forces)
        l2_completion = l2_results.get('peel_completion_time', None)
        l2_baseline = l2_results.get('true_baseline', None)
        if l2_completion is not None:
            abs_l2_completion = (l2_times[0] - times[0]) + l2_completion
            layer_data.append(('Layer 2', abs_l2_completion, 34.1, l2_baseline, 'blue'))
    except:
        pass
    
    # Create the plot
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('Enhanced Adhesion Timing Detection - Validation Results', fontsize=16, fontweight='bold')
    
    # Plot 1: Full overview
    ax1.plot(times, forces, 'k-', alpha=0.6, linewidth=0.8, label='Force Data')
    ax1.axvline(x=12.8, color='red', linestyle='--', alpha=0.7, linewidth=2, label='Layer 1 Target (12.8s)')
    ax1.axvline(x=34.1, color='blue', linestyle='--', alpha=0.7, linewidth=2, label='Layer 2 Target (34.1s)')
    
    for layer_name, detected, target, baseline, color in layer_data:
        ax1.axvline(x=detected, color=color, linestyle='-', alpha=0.9, linewidth=3, 
                   label=f'{layer_name} Detected ({detected:.1f}s)')
    
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Force (N)')
    ax1.set_title('Full Dataset - Enhanced Detection')
    ax1.grid(True, alpha=0.3)
    ax1.legend(fontsize=10)
    
    # Plot 2: Layer 1 detail (8-18s)
    l1_mask = (times >= 8) & (times <= 18)
    ax2.plot(times[l1_mask], forces[l1_mask], 'k-', linewidth=1.5, label='Layer 1 Force')
    ax2.axvline(x=12.8, color='red', linestyle='--', linewidth=2, alpha=0.7, label='Target (12.8s)')
    
    for layer_name, detected, target, baseline, color in layer_data:
        if 'Layer 1' in layer_name:
            ax2.axvline(x=detected, color=color, linestyle='-', linewidth=3, alpha=0.9, 
                       label=f'Detected ({detected:.1f}s)')
            if baseline is not None:
                ax2.axhline(y=baseline, color=color, linestyle=':', alpha=0.6, 
                           label=f'Baseline ({baseline:.4f})')
    
    ax2.set_xlabel('Time (s)')
    ax2.set_ylabel('Force (N)')
    ax2.set_title('Layer 1 Detail - Completion Detection')
    ax2.grid(True, alpha=0.3)
    ax2.legend(fontsize=10)
    
    # Plot 3: Layer 2 detail (30-38s)
    l2_mask = (times >= 30) & (times <= 38)
    ax3.plot(times[l2_mask], forces[l2_mask], 'k-', linewidth=1.5, label='Layer 2 Force')
    ax3.axvline(x=34.1, color='blue', linestyle='--', linewidth=2, alpha=0.7, label='Target (34.1s)')
    
    for layer_name, detected, target, baseline, color in layer_data:
        if 'Layer 2' in layer_name:
            ax3.axvline(x=detected, color=color, linestyle='-', linewidth=3, alpha=0.9, 
                       label=f'Detected ({detected:.1f}s)')
            if baseline is not None:
                ax3.axhline(y=baseline, color=color, linestyle=':', alpha=0.6, 
                           label=f'Baseline ({baseline:.4f})')
    
    ax3.set_xlabel('Time (s)')
    ax3.set_ylabel('Force (N)')
    ax3.set_title('Layer 2 Detail - Completion Detection')
    ax3.grid(True, alpha=0.3)
    ax3.legend(fontsize=10)
    
    # Plot 4: Accuracy summary
    if layer_data:
        layer_names = [data[0] for data in layer_data]
        errors = [abs(data[1] - data[2]) for data in layer_data]
        colors = [data[4] for data in layer_data]
        
        bars = ax4.bar(layer_names, errors, color=colors, alpha=0.7, edgecolor='black')
        ax4.set_ylabel('Timing Error (s)')
        ax4.set_title('Detection Accuracy')
        ax4.grid(True, alpha=0.3, axis='y')
        
        # Add error values on bars
        for bar, error in zip(bars, errors):
            height = bar.get_height()
            ax4.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                    f'{error:.1f}s', ha='center', va='bottom', fontweight='bold')
        
        ax4.axhline(y=0.5, color='green', linestyle='--', alpha=0.6, label='Excellent (<0.5s)')
        ax4.legend(fontsize=10)
        ax4.set_ylim(0, max(1.0, max(errors) * 1.2) if errors else 1.0)
    else:
        ax4.text(0.5, 0.5, 'No detection data', ha='center', va='center', transform=ax4.transAxes)
        ax4.set_title('Detection Accuracy')
    
    plt.tight_layout()
    plt.savefig('improved_timing_validation.png', dpi=300, bbox_inches='tight')
    print("✓ Plot saved as 'improved_timing_validation.png'")
    
    # Print results summary
    print(f"\n{'='*50}")
    print("ENHANCED TIMING DETECTION RESULTS")
    print(f"{'='*50}")
    
    for layer_name, detected, target, baseline, color in layer_data:
        error = abs(detected - target)
        accuracy = "EXCELLENT" if error < 0.5 else "GOOD" if error < 1.0 else "NEEDS WORK"
        print(f"{layer_name}:")
        print(f"  Target:   {target:.1f}s")
        print(f"  Detected: {detected:.1f}s") 
        print(f"  Error:    {error:.1f}s ({accuracy})")
        print(f"  Baseline: {baseline:.4f}")
        print()
    
    print("Improvements Made:")
    print("✓ Stable baseline from final 5% of data")
    print("✓ Sustained completion detection (8+ points)")
    print("✓ Checks for premature completion")
    print("✓ Conservative initiation thresholds")

if __name__ == "__main__":
    create_simple_timing_plot()
