"""
Analyze Three Peel Events in Multi-Layer Data
===========================================

This script identifies and analyzes the three distinct peel events 
(sawtooth patterns) at approximately 12s, 34s, and 56s.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def find_peel_events():
    """Find the three peel events (sawtooth patterns) in the data"""
    
    # Load data
    df = pd.read_csv('example_data.csv')
    time = df['Elapsed Time (s)'].values
    position = df['Position (mm)'].values
    force = df['Force (N)'].values
    
    # Define approximate time windows for each peel event
    peel_windows = [
        (10, 16),   # Around 12s
        (30, 38),   # Around 34s  
        (52, 60)    # Around 56s
    ]
    
    print("Peel Event Analysis")
    print("=" * 50)
    
    peel_results = []
    
    for i, (start_time, end_time) in enumerate(peel_windows):
        layer_num = i + 1
        print(f"\nLayer {layer_num} Peel Event ({start_time}-{end_time}s):")
        print("-" * 30)
        
        # Extract data for this time window
        mask = (time >= start_time) & (time <= end_time)
        t_window = time[mask]
        f_window = force[mask]
        p_window = position[mask]
        
        if len(t_window) == 0:
            print("No data in this time window")
            continue
        
        # Find peak force in this window
        peak_idx = np.argmax(f_window)
        peak_force = f_window[peak_idx]
        peak_time = t_window[peak_idx]
        peak_position = p_window[peak_idx]
        
        print(f"Peak force: {peak_force:.6f} N at {peak_time:.3f}s")
        print(f"Peak position: {peak_position:.4f} mm")
        
        # Find peel event boundaries using force gradient
        force_gradient = np.gradient(f_window, t_window)
        
        # Find rapid increase (start of peel)
        gradient_threshold_up = 0.1  # N/s - adjust based on data
        rapid_increase_indices = np.where(force_gradient > gradient_threshold_up)[0]
        
        if len(rapid_increase_indices) > 0:
            peel_start_idx = rapid_increase_indices[0]
            peel_start_time = t_window[peel_start_idx]
            peel_start_force = f_window[peel_start_idx]
        else:
            peel_start_idx = 0
            peel_start_time = t_window[0]
            peel_start_force = f_window[0]
        
        # Find rapid decrease (end of peel) - after peak
        post_peak_mask = np.arange(len(t_window)) > peak_idx
        post_peak_gradient = force_gradient[post_peak_mask]
        
        gradient_threshold_down = -0.1  # N/s - negative for decrease
        rapid_decrease_indices = np.where(post_peak_gradient < gradient_threshold_down)[0]
        
        if len(rapid_decrease_indices) > 0:
            # Adjust index back to full window
            peel_end_idx = peak_idx + rapid_decrease_indices[0] + 1
            peel_end_time = t_window[peel_end_idx] if peel_end_idx < len(t_window) else t_window[-1]
            peel_end_force = f_window[peel_end_idx] if peel_end_idx < len(f_window) else f_window[-1]
        else:
            peel_end_idx = len(t_window) - 1
            peel_end_time = t_window[-1]
            peel_end_force = f_window[-1]
        
        # Calculate peel event metrics
        peel_duration = peel_end_time - peel_start_time
        force_rise = peak_force - peel_start_force
        force_drop = peak_force - peel_end_force
        
        print(f"Peel start: {peel_start_time:.3f}s, Force: {peel_start_force:.6f}N")
        print(f"Peel end: {peel_end_time:.3f}s, Force: {peel_end_force:.6f}N")
        print(f"Peel duration: {peel_duration:.3f}s (< 0.5s: {peel_duration < 0.5})")
        print(f"Force rise: {force_rise:.6f}N")
        print(f"Force drop: {force_drop:.6f}N")
        print(f"Sawtooth ratio (drop/rise): {force_drop/force_rise:.2f}")
        
        # Store results
        peel_results.append({
            'layer': layer_num,
            'window_start': start_time,
            'window_end': end_time,
            'peel_start_time': peel_start_time,
            'peak_time': peak_time,
            'peel_end_time': peel_end_time,
            'peel_duration': peel_duration,
            'peel_start_force': peel_start_force,
            'peak_force': peak_force,
            'peel_end_force': peel_end_force,
            'force_rise': force_rise,
            'force_drop': force_drop
        })
    
    # Create detailed plots
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Plot 1: Full timeline with peel events marked
    ax1 = axes[0, 0]
    ax1.plot(time, force, 'b-', alpha=0.7, linewidth=1)
    for result in peel_results:
        ax1.axvspan(result['peel_start_time'], result['peel_end_time'], 
                   alpha=0.3, label=f"Layer {result['layer']} Peel")
        ax1.plot(result['peak_time'], result['peak_force'], 'ro', markersize=8)
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Force (N)')
    ax1.set_title('Full Timeline - Three Peel Events')
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    
    # Plot 2-4: Individual peel events
    for i, (result, ax) in enumerate(zip(peel_results, [axes[0,1], axes[1,0], axes[1,1]])):
        # Extract data for this peel event
        start_time, end_time = result['window_start'], result['window_end']
        mask = (time >= start_time) & (time <= end_time)
        t_peel = time[mask]
        f_peel = force[mask]
        
        ax.plot(t_peel, f_peel, 'b-', linewidth=2, label='Force')
        ax.axvline(result['peel_start_time'], color='g', linestyle='--', label='Peel Start')
        ax.axvline(result['peak_time'], color='r', linestyle='--', label='Peak')
        ax.axvline(result['peel_end_time'], color='orange', linestyle='--', label='Peel End')
        
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Force (N)')
        ax.set_title(f"Layer {result['layer']} Peel Event\nDuration: {result['peel_duration']:.3f}s")
        ax.grid(True, alpha=0.3)
        ax.legend()
    
    plt.tight_layout()
    plt.savefig('peel_events_analysis.png', dpi=150, bbox_inches='tight')
    plt.show()
    
    # Summary
    print("\n" + "=" * 50)
    print("PEEL EVENTS SUMMARY:")
    print("=" * 50)
    
    durations = [r['peel_duration'] for r in peel_results]
    peak_forces = [r['peak_force'] for r in peel_results]
    
    print(f"Average peel duration: {np.mean(durations):.3f}s")
    print(f"All peels < 0.5s: {all(d < 0.5 for d in durations)}")
    print(f"Peak force range: {min(peak_forces):.6f} to {max(peak_forces):.6f} N")
    print(f"Peak force variation: {np.std(peak_forces)/np.mean(peak_forces)*100:.1f}%")
    
    return peel_results

if __name__ == "__main__":
    results = find_peel_events()
