"""
Analyze Real Force Data from User
=================================

This script analyzes the user's actual force data to understand:
1. When the stage starts moving
2. Peak force timing and characteristics  
3. Three-phase behavior (pre-initiation, initiation, propagation)
4. Noise characteristics
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def analyze_real_force_data():
    """Analyze the user's actual force data"""
    
    # Load the data
    df = pd.read_csv('example_data.csv')
    time = df['Elapsed Time (s)'].values
    position = df['Position (mm)'].values
    force = df['Force (N)'].values
    
    print("Real Force Data Analysis")
    print("=" * 40)
    print(f"Data points: {len(time)}")
    print(f"Time range: {time.min():.3f} to {time.max():.3f} seconds")
    print(f"Position range: {position.min():.3f} to {position.max():.3f} mm")
    print(f"Force range: {force.min():.6f} to {force.max():.6f} N")
    
    # Find when stage starts moving (position change)
    position_diff = np.diff(position)
    moving_threshold = 0.001  # mm
    movement_start_idx = np.where(np.abs(position_diff) > moving_threshold)[0]
    
    if len(movement_start_idx) > 0:
        movement_start_time = time[movement_start_idx[0]]
        print(f"\nStage movement starts at: {movement_start_time:.3f} seconds")
        print(f"Position at movement start: {position[movement_start_idx[0]]:.4f} mm")
        print(f"Force at movement start: {force[movement_start_idx[0]]:.6f} N")
    else:
        movement_start_time = time[0]
        print("\nNo clear movement detected - stage may be moving throughout")
    
    # Find peak force and timing
    peak_force_idx = np.argmax(force)
    peak_force = force[peak_force_idx]
    peak_time = time[peak_force_idx]
    peak_position = position[peak_force_idx]
    
    print(f"\nPeak Force Analysis:")
    print(f"Peak force: {peak_force:.6f} N")
    print(f"Peak time: {peak_time:.3f} seconds")
    print(f"Peak position: {peak_position:.4f} mm")
    
    if len(movement_start_idx) > 0:
        time_to_peak = peak_time - movement_start_time
        print(f"Time from movement start to peak: {time_to_peak:.3f} seconds")
        print(f"Peak occurs in < 0.5s? {time_to_peak < 0.5}")
    
    # Analyze baseline behavior
    print(f"\nBaseline Analysis:")
    
    # Initial baseline (before movement)
    if len(movement_start_idx) > 0:
        initial_baseline = np.mean(force[:movement_start_idx[0]])
        initial_std = np.std(force[:movement_start_idx[0]])
        print(f"Initial baseline (before movement): {initial_baseline:.6f} ± {initial_std:.6f} N")
    
    # Final baseline (last 10% of data)
    final_baseline_data = force[int(len(force)*0.9):]
    final_baseline = np.mean(final_baseline_data)
    final_std = np.std(final_baseline_data)
    print(f"Final baseline (last 10%): {final_baseline:.6f} ± {final_std:.6f} N")
    
    # Noise analysis
    noise_estimate = np.std(force[:min(100, len(force)//4)])  # First quarter of data
    noise_percentage = (noise_estimate / peak_force) * 100
    print(f"Estimated noise: {noise_estimate:.6f} N ({noise_percentage:.1f}% of peak)")
    
    # Sampling rate analysis
    dt_values = np.diff(time)
    avg_dt = np.mean(dt_values)
    sampling_rate = 1.0 / avg_dt
    print(f"\nSampling Analysis:")
    print(f"Average sampling interval: {avg_dt*1000:.1f} ms")
    print(f"Average sampling rate: {sampling_rate:.1f} Hz")
    print(f"Target 10-20ms achieved? {10 <= avg_dt*1000 <= 20}")
    
    # Three-phase identification
    print(f"\nThree-Phase Analysis:")
    
    # Pre-initiation: from start to force starts increasing significantly
    force_gradient = np.gradient(force, time)
    gradient_threshold = 3 * noise_estimate / np.mean(dt_values)  # 3x noise level
    
    significant_increase_idx = np.where(force_gradient > gradient_threshold)[0]
    if len(significant_increase_idx) > 0:
        pre_initiation_end = time[significant_increase_idx[0]]
        print(f"Pre-initiation phase: 0 to {pre_initiation_end:.3f} s")
        
        # Initiation: from force increase to peak
        initiation_duration = peak_time - pre_initiation_end
        print(f"Initiation phase: {pre_initiation_end:.3f} to {peak_time:.3f} s (duration: {initiation_duration:.3f} s)")
        
        # Propagation: from peak to end
        propagation_duration = time[-1] - peak_time
        print(f"Propagation phase: {peak_time:.3f} to {time[-1]:.3f} s (duration: {propagation_duration:.3f} s)")
    
    # Generate a simple plot
    plt.figure(figsize=(12, 8))
    
    plt.subplot(2, 1, 1)
    plt.plot(time, position, 'b-', label='Position')
    plt.axvline(movement_start_time, color='g', linestyle='--', label='Movement Start')
    plt.axvline(peak_time, color='r', linestyle='--', label='Peak Force Time')
    plt.xlabel('Time (s)')
    plt.ylabel('Position (mm)')
    plt.title('Stage Position vs Time')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.subplot(2, 1, 2)
    plt.plot(time, force, 'r-', label='Force', linewidth=1)
    plt.axhline(0, color='k', linestyle='-', alpha=0.3, label='Zero Force')
    plt.axhline(final_baseline, color='purple', linestyle='--', label='Final Baseline')
    plt.axvline(movement_start_time, color='g', linestyle='--', label='Movement Start')
    plt.axvline(peak_time, color='r', linestyle='--', label='Peak Force')
    plt.xlabel('Time (s)')
    plt.ylabel('Force (N)')
    plt.title('Force vs Time')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('force_analysis.png', dpi=150, bbox_inches='tight')
    plt.show()
    
    return {
        'peak_force': peak_force,
        'peak_time': peak_time,
        'time_to_peak': time_to_peak if len(movement_start_idx) > 0 else np.nan,
        'movement_start_time': movement_start_time,
        'noise_percentage': noise_percentage,
        'sampling_rate': sampling_rate,
        'initial_baseline': initial_baseline if len(movement_start_idx) > 0 else np.nan,
        'final_baseline': final_baseline
    }

if __name__ == "__main__":
    results = analyze_real_force_data()
    print(f"\nSUMMARY:")
    print(f"✓ Peak occurs in {results['time_to_peak']:.3f}s (< 0.5s: {results['time_to_peak'] < 0.5})")
    print(f"✓ Noise level: {results['noise_percentage']:.1f}% of peak")
    print(f"✓ Sampling rate: {results['sampling_rate']:.1f} Hz")
