#!/usr/bin/env python3
"""
Force Gauge Logging Rate Test
Tests if we're achieving the target logging rate
"""

import time
import csv
from datetime import datetime

def analyze_logging_timestamps(csv_file_path):
    """Analyze timestamps in a force gauge log file."""
    print(f"=== Analyzing Logging Rate in {csv_file_path} ===")
    
    timestamps = []
    forces = []
    
    try:
        with open(csv_file_path, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                if len(row) >= 3:
                    try:
                        timestamp = float(row[0])
                        force = float(row[2])
                        timestamps.append(timestamp)
                        forces.append(force)
                    except ValueError:
                        continue  # Skip header or invalid rows
        
        if len(timestamps) < 2:
            print("Not enough data points to analyze")
            return
        
        # Calculate intervals
        intervals = []
        for i in range(1, len(timestamps)):
            interval = timestamps[i] - timestamps[i-1]
            intervals.append(interval)
        
        # Statistics
        avg_interval = sum(intervals) / len(intervals)
        min_interval = min(intervals)
        max_interval = max(intervals)
        actual_rate = 1.0 / avg_interval if avg_interval > 0 else 0
        
        # Count intervals by range
        target_20ms = 0.020  # 20ms target
        good_intervals = sum(1 for i in intervals if 0.015 <= i <= 0.025)  # Within ±5ms
        total_intervals = len(intervals)
        
        print(f"Data points: {len(timestamps)}")
        print(f"Time span: {timestamps[-1] - timestamps[0]:.3f} seconds")
        print(f"Average interval: {avg_interval*1000:.2f} ms")
        print(f"Min interval: {min_interval*1000:.2f} ms")
        print(f"Max interval: {max_interval*1000:.2f} ms")
        print(f"Actual sample rate: {actual_rate:.1f} Hz")
        print(f"Target rate (20ms): 50.0 Hz")
        print(f"Good intervals (±5ms): {good_intervals}/{total_intervals} ({100*good_intervals/total_intervals:.1f}%)")
        
        # Show some problematic intervals
        bad_intervals = [(i, intervals[i]*1000) for i in range(len(intervals)) if intervals[i] > 0.030]
        if bad_intervals:
            print(f"\nLarge gaps (>30ms):")
            for idx, interval_ms in bad_intervals[:10]:  # Show first 10
                print(f"  Position {idx}: {interval_ms:.1f} ms")
        
        return {
            'avg_rate': actual_rate,
            'good_percentage': 100*good_intervals/total_intervals,
            'total_points': len(timestamps)
        }
        
    except FileNotFoundError:
        print(f"File not found: {csv_file_path}")
        return None
    except Exception as e:
        print(f"Error analyzing file: {e}")
        return None

def create_test_suggestions():
    """Provide suggestions for improving logging rate."""
    print("\n=== Suggestions for Improving Logging Rate ===")
    print("1. In your main application, call:")
    print("   force_gauge_manager.set_high_frequency_logging(True)")
    print("2. Check performance stats:")
    print("   stats = force_gauge_manager.get_performance_stats()")
    print("   print(stats)")
    print("3. Monitor console output for 'Force gauge: X.X Hz actual rate'")
    print("4. If rate is still low, try:")
    print("   - Increase raw_data_queue maxsize")
    print("   - Reduce GUI update frequency")
    print("   - Check USB coordinator timing")

if __name__ == "__main__":
    # You can provide a path to your log file here
    log_file = input("Enter path to force gauge log file (or press Enter to show suggestions): ").strip()
    
    if log_file and log_file != "":
        analyze_logging_timestamps(log_file)
    else:
        create_test_suggestions()
        
    print("\n=== Tips ===")
    print("- Target: 20ms intervals (50 Hz)")
    print("- Good performance: >90% intervals within ±5ms")
    print("- Check console for 'Force gauge: X.X Hz actual rate' messages")
