#!/usr/bin/env python3
"""
Complete Three-Layer Timing Validation Plot
==========================================

Creates detailed plots for all three layers with improved timing detection.
Adjusts Layer 1 detection to be slightly later and includes Layer 3 analysis.
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from enhanced_adhesion_metrics import EnhancedAdhesionAnalyzer

def create_complete_three_layer_plot():
    """Create comprehensive plot showing all three layers with improved timing"""
    
    print("Creating complete three-layer timing validation plot...")
    
    # Load data
    times, forces, positions = [], [], []
    
    with open('example_data.csv', 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:  # Skip header
            parts = line.strip().split(',')
            if len(parts) >= 3:
                times.append(float(parts[0]))
                positions.append(float(parts[1]))
                forces.append(float(parts[2]))
    
    times = np.array(times)
    forces = np.array(forces)
    positions = np.array(positions)
    
    print(f"Loaded {len(times)} data points from {times.min():.1f}s to {times.max():.1f}s")
    
    # Create analyzer with slightly adjusted parameters for better Layer 1 timing
    analyzer = EnhancedAdhesionAnalyzer(noise_threshold=0.035)  # Slightly less sensitive
    
    # Analyze all three layers with better segmentation
    layer_data = []
    
    # Layer 1: 0-24s (approximately 0-800 points)
    print("Analyzing Layer 1...")
    l1_end = min(850, len(times))  # Slightly larger window
    l1_times = times[0:l1_end]
    l1_forces = forces[0:l1_end]
    l1_positions = positions[0:l1_end]
    try:
        l1_results = analyzer.analyze_peel_data(l1_times, l1_positions, l1_forces)
        l1_completion = l1_results.get('peel_completion_time', None)
        l1_baseline = l1_results.get('true_baseline', None)
        l1_peak_time = l1_results.get('peak_force_time', None)
        if l1_completion is not None:
            abs_l1_completion = (l1_times[0] - times[0]) + l1_completion
            layer_data.append(('Layer 1', abs_l1_completion, 12.8, l1_baseline, l1_peak_time, 'red'))
            print(f"  Layer 1 completion: {abs_l1_completion:.1f}s (target: 12.8s)")
    except Exception as e:
        print(f"  Layer 1 analysis error: {e}")
    
    # Layer 2: 24-48s (approximately 800-1600 points)
    print("Analyzing Layer 2...")
    l2_start = 800
    l2_end = min(1650, len(times))  # Slightly larger window
    l2_times = times[l2_start:l2_end]
    l2_forces = forces[l2_start:l2_end]
    l2_positions = positions[l2_start:l2_end]
    try:
        l2_results = analyzer.analyze_peel_data(l2_times, l2_positions, l2_forces)
        l2_completion = l2_results.get('peel_completion_time', None)
        l2_baseline = l2_results.get('true_baseline', None)
        l2_peak_time = l2_results.get('peak_force_time', None)
        if l2_completion is not None:
            abs_l2_completion = (l2_times[0] - times[0]) + l2_completion
            layer_data.append(('Layer 2', abs_l2_completion, 34.1, l2_baseline, l2_peak_time, 'blue'))
            print(f"  Layer 2 completion: {abs_l2_completion:.1f}s (target: 34.1s)")
    except Exception as e:
        print(f"  Layer 2 analysis error: {e}")
    
    # Layer 3: 48-67s (approximately 1600-2260 points)
    print("Analyzing Layer 3...")
    l3_start = 1600
    l3_end = len(times)
    l3_times = times[l3_start:l3_end]
    l3_forces = forces[l3_start:l3_end]
    l3_positions = positions[l3_start:l3_end]
    try:
        l3_results = analyzer.analyze_peel_data(l3_times, l3_positions, l3_forces)
        l3_completion = l3_results.get('peel_completion_time', None)
        l3_baseline = l3_results.get('true_baseline', None)
        l3_peak_time = l3_results.get('peak_force_time', None)
        if l3_completion is not None:
            abs_l3_completion = (l3_times[0] - times[0]) + l3_completion
            layer_data.append(('Layer 3', abs_l3_completion, None, l3_baseline, l3_peak_time, 'green'))
            print(f"  Layer 3 completion: {abs_l3_completion:.1f}s (no target - estimated)")
    except Exception as e:
        print(f"  Layer 3 analysis error: {e}")
    
    # Create comprehensive plot with 2x3 layout
    fig, axes = plt.subplots(2, 3, figsize=(20, 12))
    fig.suptitle('Enhanced Three-Layer Adhesion Timing Detection - Complete Validation', 
                 fontsize=18, fontweight='bold')
    
    # Plot 1: Full dataset overview (top left)
    ax1 = axes[0, 0]
    ax1.plot(times, forces, 'k-', alpha=0.6, linewidth=0.8, label='Force Data')
    
    # Add target lines
    ax1.axvline(x=12.8, color='red', linestyle='--', alpha=0.7, linewidth=2, label='L1 Target (12.8s)')
    ax1.axvline(x=34.1, color='blue', linestyle='--', alpha=0.7, linewidth=2, label='L2 Target (34.1s)')
    
    # Add detected completions
    for layer_name, detected, target, baseline, peak_time, color in layer_data:
        ax1.axvline(x=detected, color=color, linestyle='-', alpha=0.9, linewidth=3, 
                   label=f'{layer_name} Detected ({detected:.1f}s)')
    
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Force (N)')
    ax1.set_title('Full Dataset Overview')
    ax1.grid(True, alpha=0.3)
    ax1.legend(fontsize=9)
    
    # Plot 2: Layer 1 detail (top middle)
    ax2 = axes[0, 1]
    l1_detail_mask = (times >= 8) & (times <= 18)
    ax2.plot(times[l1_detail_mask], forces[l1_detail_mask], 'k-', linewidth=1.5, label='Layer 1 Force')
    ax2.axvline(x=12.8, color='red', linestyle='--', linewidth=2, alpha=0.7, label='Target (12.8s)')
    
    for layer_name, detected, target, baseline, peak_time, color in layer_data:
        if 'Layer 1' in layer_name:
            ax2.axvline(x=detected, color=color, linestyle='-', linewidth=3, alpha=0.9, 
                       label=f'Detected ({detected:.1f}s)')
            if baseline is not None:
                ax2.axhline(y=baseline, color=color, linestyle=':', alpha=0.6, 
                           label=f'Baseline ({baseline:.4f})')
            if peak_time is not None:
                abs_peak = (l1_times[0] - times[0]) + peak_time
                ax2.axvline(x=abs_peak, color=color, linestyle='-.', alpha=0.5, 
                           label=f'Peak ({abs_peak:.1f}s)')
    
    ax2.set_xlabel('Time (s)')
    ax2.set_ylabel('Force (N)')
    ax2.set_title('Layer 1 Detail (8-18s)')
    ax2.grid(True, alpha=0.3)
    ax2.legend(fontsize=9)
    
    # Plot 3: Layer 2 detail (top right)
    ax3 = axes[0, 2]
    l2_detail_mask = (times >= 30) & (times <= 38)
    ax3.plot(times[l2_detail_mask], forces[l2_detail_mask], 'k-', linewidth=1.5, label='Layer 2 Force')
    ax3.axvline(x=34.1, color='blue', linestyle='--', linewidth=2, alpha=0.7, label='Target (34.1s)')
    
    for layer_name, detected, target, baseline, peak_time, color in layer_data:
        if 'Layer 2' in layer_name:
            ax3.axvline(x=detected, color=color, linestyle='-', linewidth=3, alpha=0.9, 
                       label=f'Detected ({detected:.1f}s)')
            if baseline is not None:
                ax3.axhline(y=baseline, color=color, linestyle=':', alpha=0.6, 
                           label=f'Baseline ({baseline:.4f})')
            if peak_time is not None:
                abs_peak = (l2_times[0] - times[0]) + peak_time
                ax3.axvline(x=abs_peak, color=color, linestyle='-.', alpha=0.5, 
                           label=f'Peak ({abs_peak:.1f}s)')
    
    ax3.set_xlabel('Time (s)')
    ax3.set_ylabel('Force (N)')
    ax3.set_title('Layer 2 Detail (30-38s)')
    ax3.grid(True, alpha=0.3)
    ax3.legend(fontsize=9)
    
    # Plot 4: Layer 3 detail (bottom left)
    ax4 = axes[1, 0]
    l3_detail_mask = (times >= 52) & (times <= 62)
    ax4.plot(times[l3_detail_mask], forces[l3_detail_mask], 'k-', linewidth=1.5, label='Layer 3 Force')
    
    for layer_name, detected, target, baseline, peak_time, color in layer_data:
        if 'Layer 3' in layer_name:
            ax4.axvline(x=detected, color=color, linestyle='-', linewidth=3, alpha=0.9, 
                       label=f'Detected ({detected:.1f}s)')
            if baseline is not None:
                ax4.axhline(y=baseline, color=color, linestyle=':', alpha=0.6, 
                           label=f'Baseline ({baseline:.4f})')
            if peak_time is not None:
                abs_peak = (l3_times[0] - times[0]) + peak_time
                ax4.axvline(x=abs_peak, color=color, linestyle='-.', alpha=0.5, 
                           label=f'Peak ({abs_peak:.1f}s)')
    
    ax4.set_xlabel('Time (s)')
    ax4.set_ylabel('Force (N)')
    ax4.set_title('Layer 3 Detail (52-62s)')
    ax4.grid(True, alpha=0.3)
    ax4.legend(fontsize=9)
    
    # Plot 5: Accuracy summary (bottom middle)
    ax5 = axes[1, 1]
    
    if layer_data:
        layers_with_targets = [(name, detected, target, color) for name, detected, target, baseline, peak_time, color in layer_data if target is not None]
        
        if layers_with_targets:
            layer_names = [data[0] for data in layers_with_targets]
            errors = [abs(data[1] - data[2]) for data in layers_with_targets]
            colors = [data[3] for data in layers_with_targets]
            
            bars = ax5.bar(layer_names, errors, color=colors, alpha=0.7, edgecolor='black')
            ax5.set_ylabel('Timing Error (s)')
            ax5.set_title('Detection Accuracy vs Targets')
            ax5.grid(True, alpha=0.3, axis='y')
            
            # Add error values on bars
            for bar, error in zip(bars, errors):
                height = bar.get_height()
                ax5.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                        f'{error:.2f}s', ha='center', va='bottom', fontweight='bold')
            
            ax5.axhline(y=0.5, color='green', linestyle='--', alpha=0.6, label='Excellent (<0.5s)')
            ax5.axhline(y=1.0, color='orange', linestyle='--', alpha=0.6, label='Good (<1.0s)')
            ax5.legend(fontsize=9)
            ax5.set_ylim(0, max(1.2, max(errors) * 1.2) if errors else 1.2)
        else:
            ax5.text(0.5, 0.5, 'No target comparisons available', 
                    ha='center', va='center', transform=ax5.transAxes)
    else:
        ax5.text(0.5, 0.5, 'No detection data available', 
                ha='center', va='center', transform=ax5.transAxes)
    
    # Plot 6: Timeline comparison (bottom right)
    ax6 = axes[1, 2]
    
    if layer_data:
        y_positions = range(len(layer_data))
        layer_names = [data[0] for data in layer_data]
        detected_times = [data[1] for data in layer_data]
        colors = [data[5] for data in layer_data]
        
        # Plot detected times
        ax6.barh(y_positions, detected_times, color=colors, alpha=0.7, label='Detected Times')
        
        # Add target lines where available
        targets = [12.8, 34.1]  # Known targets
        target_colors = ['red', 'blue']
        for i, (target, target_color) in enumerate(zip(targets, target_colors)):
            if i < len(y_positions):
                ax6.axvline(x=target, color=target_color, linestyle='--', alpha=0.7)
        
        ax6.set_yticks(y_positions)
        ax6.set_yticklabels(layer_names)
        ax6.set_xlabel('Time (s)')
        ax6.set_title('Layer Completion Timeline')
        ax6.grid(True, alpha=0.3, axis='x')
        
        # Add time annotations
        for i, (detected, color) in enumerate(zip(detected_times, colors)):
            ax6.text(detected + 1, i, f'{detected:.1f}s', va='center', fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('complete_three_layer_validation.png', dpi=300, bbox_inches='tight')
    print("✓ Plot saved as 'complete_three_layer_validation.png'")
    
    # Print comprehensive results summary
    print(f"\n{'='*70}")
    print("COMPLETE THREE-LAYER TIMING DETECTION RESULTS")
    print(f"{'='*70}")
    
    for layer_name, detected, target, baseline, peak_time, color in layer_data:
        print(f"\n{layer_name}:")
        if target is not None:
            error = abs(detected - target)
            accuracy = "EXCELLENT" if error < 0.5 else "GOOD" if error < 1.0 else "NEEDS WORK"
            print(f"  Target:     {target:.1f}s")
            print(f"  Detected:   {detected:.1f}s") 
            print(f"  Error:      {error:.2f}s ({accuracy})")
        else:
            print(f"  Detected:   {detected:.1f}s (no target available)")
        
        print(f"  Baseline:   {baseline:.4f}")
        if peak_time is not None:
            abs_peak = detected - (l3_completion if 'Layer 3' in layer_name else (l2_completion if 'Layer 2' in layer_name else l1_completion)) + peak_time
            print(f"  Peak time:  {abs_peak:.1f}s")
    
    print(f"\n{'='*70}")
    print("ALGORITHM STATUS:")
    print("✓ Enhanced baseline correction (5% final data + stability)")
    print("✓ Sustained completion detection (8+ consecutive points)")
    print("✓ Conservative initiation detection (5 consecutive points)")
    print("✓ All three layers analyzed and plotted")

if __name__ == "__main__":
    create_complete_three_layer_plot()
