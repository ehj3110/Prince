#!/usr/bin/env python3
"""
Quick Test of Improved Timing Detection
=======================================

Tests the enhanced baseline correction and completion detection
against your specific observations:
- Layer 1 propagation ends at ~12.8s
- Layer 2 propagation ends at ~34.1-34.2s
"""

def quick_test():
    """Quick test of improvements"""
    
    print("Quick Test - Improved Timing Detection")
    print("=" * 50)
    
    # Read data manually (no pandas needed)
    times, forces, positions = [], [], []
    
    try:
        with open('example_data.csv', 'r') as f:
            lines = f.readlines()
            for line in lines[1:]:  # Skip header
                parts = line.strip().split(',')
                if len(parts) >= 3:
                    times.append(float(parts[0]))
                    positions.append(float(parts[1]))
                    forces.append(float(parts[2]))
        
        print(f"✓ Loaded {len(times)} data points")
    except Exception as e:
        print(f"✗ Error loading data: {e}")
        return
    
    import numpy as np
    from enhanced_adhesion_metrics import EnhancedAdhesionAnalyzer
    
    times = np.array(times)
    forces = np.array(forces)
    positions = np.array(positions)
    
    # Create analyzer with improved settings
    analyzer = EnhancedAdhesionAnalyzer(noise_threshold=0.04)
    
    print(f"\nData Range: {times.min():.1f}s to {times.max():.1f}s")
    print(f"Target completions: Layer 1=12.8s, Layer 2=34.1s")
    print("\nTesting individual layers...")
    
    # Test Layer 1 (around 0-24s)
    print(f"\n--- Layer 1 Test ---")
    l1_end = min(800, len(times))
    l1_times = times[0:l1_end] 
    l1_forces = forces[0:l1_end]
    l1_positions = positions[0:l1_end]
    
    try:
        l1_results = analyzer.analyze_peel_data(l1_times, l1_positions, l1_forces)
        l1_completion = l1_results.get('peel_completion_time', 'N/A')
        l1_baseline = l1_results.get('true_baseline', 'N/A')
        
        if l1_completion != 'N/A':
            abs_completion = (l1_times[0] - times[0]) + l1_completion
            error = abs(abs_completion - 12.8)
            print(f"Completion: {l1_completion:.1f}s (absolute: {abs_completion:.1f}s)")
            print(f"Target: 12.8s, Error: {error:.1f}s")
            print(f"Baseline: {l1_baseline:.4f}")
            
            if error < 0.5:
                print("✓ EXCELLENT accuracy!")
            elif error < 1.0:
                print("✓ Good accuracy")
            else:
                print("⚠ Needs work")
        else:
            print("✗ Could not detect completion")
    except Exception as e:
        print(f"✗ Layer 1 error: {e}")
    
    # Test Layer 2 (around 24-48s) 
    print(f"\n--- Layer 2 Test ---")
    l2_start = min(800, len(times))
    l2_end = min(1600, len(times))
    l2_times = times[l2_start:l2_end]
    l2_forces = forces[l2_start:l2_end] 
    l2_positions = positions[l2_start:l2_end]
    
    try:
        l2_results = analyzer.analyze_peel_data(l2_times, l2_positions, l2_forces)
        l2_completion = l2_results.get('peel_completion_time', 'N/A')
        l2_baseline = l2_results.get('true_baseline', 'N/A')
        
        if l2_completion != 'N/A':
            abs_completion = (l2_times[0] - times[0]) + l2_completion
            error = abs(abs_completion - 34.1)
            print(f"Completion: {l2_completion:.1f}s (absolute: {abs_completion:.1f}s)")
            print(f"Target: 34.1s, Error: {error:.1f}s")
            print(f"Baseline: {l2_baseline:.4f}")
            
            if error < 0.5:
                print("✓ EXCELLENT accuracy!")
            elif error < 1.0:
                print("✓ Good accuracy")  
            else:
                print("⚠ Needs work")
        else:
            print("✗ Could not detect completion")
    except Exception as e:
        print(f"✗ Layer 2 error: {e}")
    
    # Quick baseline comparison
    print(f"\n--- Baseline Quality Check ---")
    end_forces = forces[-100:]  # Last 100 points
    start_forces = forces[:100]  # First 100 points
    mid_forces = forces[1000:1100]  # Middle region
    
    print(f"Start region:  {np.mean(start_forces):.4f} ± {np.std(start_forces):.4f}")
    print(f"Middle region: {np.mean(mid_forces):.4f} ± {np.std(mid_forces):.4f}")
    print(f"End region:    {np.mean(end_forces):.4f} ± {np.std(end_forces):.4f}")
    
    print(f"\n{'='*50}")
    print("Summary: The improved algorithm should now:")
    print("1. Use a more stable baseline from final data")
    print("2. Require sustained return to baseline (8+ points)")
    print("3. Check for later significant force activity")
    print("4. Provide better completion timing accuracy")

if __name__ == "__main__":
    quick_test()
