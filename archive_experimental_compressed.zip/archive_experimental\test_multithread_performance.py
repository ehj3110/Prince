#!/usr/bin/env python3
"""
Force Gauge Performance Test Script
Tests the new multi-threaded architecture
"""

import time
import threading
from ForceGaugeManager import ForceGaugeManager
import queue

def performance_test():
    print("=== Force Gauge Multi-Threading Performance Test ===")
    
    # Create mock GUI components
    class MockLabel:
        def __init__(self):
            self.text = ""
        def config(self, text=""):
            self.text = text
        def winfo_exists(self):
            return True
    
    class MockWindow:
        def after_idle(self, func, *args):
            # Execute immediately for testing
            func(*args)
        def after(self, delay, func):
            func()
    
    # Create mock components
    mock_gain_label = MockLabel()
    mock_offset_label = MockLabel()
    mock_force_status = MockLabel()
    mock_large_readout = MockLabel()
    mock_output_queue = queue.Queue(maxsize=1000)
    mock_window = MockWindow()
    mock_sensor_window = None
    
    # Create ForceGaugeManager (will start background threads)
    print("Creating ForceGaugeManager with multi-threading...")
    fgm = ForceGaugeManager(
        mock_gain_label, mock_offset_label, mock_force_status, 
        mock_large_readout, mock_output_queue, mock_window, mock_sensor_window
    )
    
    # Wait for initialization
    print("Waiting for initialization...")
    time.sleep(3)
    
    # Monitor performance for 10 seconds
    print("Monitoring performance for 10 seconds...")
    for i in range(10):
        time.sleep(1)
        stats = fgm.get_performance_stats()
        print(f"Second {i+1}: {stats['actual_sample_rate']:.1f} Hz, "
              f"Raw queue: {stats['raw_queue_size']}/{stats['raw_queue_max']}, "
              f"Buffer: {stats['buffer_size']}")
    
    # Test cleanup
    print("Testing cleanup...")
    fgm.close()
    
    print("=== Test Complete ===")

if __name__ == "__main__":
    try:
        performance_test()
    except KeyboardInterrupt:
        print("\nTest interrupted by user")
    except Exception as e:
        print(f"Test error: {e}")
        import traceback
        traceback.print_exc()
