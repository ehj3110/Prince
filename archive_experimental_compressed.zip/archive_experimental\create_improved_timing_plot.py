#!/usr/bin/env python3
"""
Visual Validation of Improved Timing Detection
=============================================

Creates plots showing the enhanced baseline correction and completion detection
against your target times: Layer 1 = 12.8s, Layer 2 = 34.1s
"""

import numpy as np
import matplotlib.pyplot as plt
from enhanced_adhesion_metrics import EnhancedAdhesionAnalyzer

def create_improved_timing_plot():
    """Create comprehensive plot showing improved timing detection"""
    
    # Load data
    times, forces, positions = [], [], []
    
    try:
        with open('example_data.csv', 'r') as f:
            lines = f.readlines()
            for line in lines[1:]:  # Skip header
                parts = line.strip().split(',')
                if len(parts) >= 3:
                    times.append(float(parts[0]))
                    positions.append(float(parts[1]))
                    forces.append(float(parts[2]))
    except Exception as e:
        print(f"Error loading data: {e}")
        return
    
    times = np.array(times)
    forces = np.array(forces)
    positions = np.array(positions)
    
    print(f"Creating improved timing plot with {len(times)} data points...")
    
    # Create analyzer
    analyzer = EnhancedAdhesionAnalyzer(noise_threshold=0.04)
    
    # Analyze individual layers
    layer_segments = [
        ("Layer 1", 0, 800, 12.8, 'red'),
        ("Layer 2", 800, 1600, 34.1, 'blue'),
        ("Layer 3", 1600, 2200, None, 'green')
    ]
    
    # Create comprehensive plot
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('Enhanced Adhesion Timing Detection - Validation Results', fontsize=16, fontweight='bold')
    
    # Plot 1: Full dataset overview
    ax1 = axes[0, 0]
    ax1.plot(times, forces, 'k-', alpha=0.7, linewidth=0.8, label='Raw Force Data')
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Force (N)')
    ax1.set_title('Full Dataset - Enhanced Detection Results')
    ax1.grid(True, alpha=0.3)
    
    # Add target lines and detection results
    target_times = [12.8, 34.1]
    target_labels = ['Layer 1 Target (12.8s)', 'Layer 2 Target (34.1s)']
    colors = ['red', 'blue']
    
    for target_time, label, color in zip(target_times, target_labels, colors):
        ax1.axvline(x=target_time, color=color, linestyle='--', alpha=0.7, linewidth=2, label=label)
    
    # Analyze and mark detection results
    detection_results = []
    
    for layer_name, start_idx, end_idx, target, color in layer_segments:
        if target is None:
            continue
            
        seg_times = times[start_idx:end_idx]
        seg_forces = forces[start_idx:end_idx]
        seg_positions = positions[start_idx:end_idx]
        
        try:
            results = analyzer.analyze_peel_data(seg_times, seg_positions, seg_forces)
            completion = results.get('peel_completion_time', None)
            baseline = results.get('true_baseline', None)
            
            if completion is not None:
                abs_completion = (seg_times[0] - times[0]) + completion
                detection_results.append((layer_name, abs_completion, target, baseline, color))
                
                # Mark detected completion
                ax1.axvline(x=abs_completion, color=color, linestyle='-', alpha=0.9, linewidth=3, 
                           label=f'{layer_name} Detected ({abs_completion:.1f}s)')
        except Exception as e:
            print(f"Error analyzing {layer_name}: {e}")
    
    ax1.legend(loc='upper right', fontsize=10)
    
    # Plot 2: Layer 1 detailed view
    ax2 = axes[0, 1]
    l1_mask = (times >= 8) & (times <= 18)
    l1_detail_times = times[l1_mask]
    l1_detail_forces = forces[l1_mask]
    
    ax2.plot(l1_detail_times, l1_detail_forces, 'k-', linewidth=1.5, label='Layer 1 Data')
    ax2.axvline(x=12.8, color='red', linestyle='--', linewidth=2, alpha=0.7, label='Target (12.8s)')
    
    # Add detected completion if available
    for layer_name, detected, target, baseline, color in detection_results:
        if 'Layer 1' in layer_name:
            ax2.axvline(x=detected, color=color, linestyle='-', linewidth=3, alpha=0.9, 
                       label=f'Detected ({detected:.1f}s)')
            if baseline is not None:
                ax2.axhline(y=baseline, color=color, linestyle=':', alpha=0.6, 
                           label=f'Baseline ({baseline:.4f})')
    
    ax2.set_xlabel('Time (s)')
    ax2.set_ylabel('Force (N)')
    ax2.set_title('Layer 1 Detail - Enhanced Completion Detection')
    ax2.grid(True, alpha=0.3)
    ax2.legend(fontsize=10)
    
    # Plot 3: Layer 2 detailed view
    ax3 = axes[1, 0]
    l2_mask = (times >= 30) & (times <= 38)
    l2_detail_times = times[l2_mask]
    l2_detail_forces = forces[l2_mask]
    
    ax3.plot(l2_detail_times, l2_detail_forces, 'k-', linewidth=1.5, label='Layer 2 Data')
    ax3.axvline(x=34.1, color='blue', linestyle='--', linewidth=2, alpha=0.7, label='Target (34.1s)')
    
    # Add detected completion if available
    for layer_name, detected, target, baseline, color in detection_results:
        if 'Layer 2' in layer_name:
            ax3.axvline(x=detected, color=color, linestyle='-', linewidth=3, alpha=0.9, 
                       label=f'Detected ({detected:.1f}s)')
            if baseline is not None:
                ax3.axhline(y=baseline, color=color, linestyle=':', alpha=0.6, 
                           label=f'Baseline ({baseline:.4f})')
    
    ax3.set_xlabel('Time (s)')
    ax3.set_ylabel('Force (N)')
    ax3.set_title('Layer 2 Detail - Enhanced Completion Detection')
    ax3.grid(True, alpha=0.3)
    ax3.legend(fontsize=10)
    
    # Plot 4: Accuracy summary
    ax4 = axes[1, 1]
    
    if detection_results:
        layer_names = []
        errors = []
        colors_plot = []
        
        for layer_name, detected, target, baseline, color in detection_results:
            layer_names.append(layer_name)
            error = abs(detected - target)
            errors.append(error)
            colors_plot.append(color)
        
        bars = ax4.bar(layer_names, errors, color=colors_plot, alpha=0.7, edgecolor='black')
        ax4.set_ylabel('Timing Error (s)')
        ax4.set_title('Detection Accuracy Summary')
        ax4.grid(True, alpha=0.3, axis='y')
        
        # Add error values on bars
        for bar, error in zip(bars, errors):
            height = bar.get_height()
            ax4.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                    f'{error:.1f}s', ha='center', va='bottom', fontweight='bold')
        
        # Add accuracy thresholds
        ax4.axhline(y=0.5, color='green', linestyle='--', alpha=0.6, label='Excellent (<0.5s)')
        ax4.axhline(y=1.0, color='orange', linestyle='--', alpha=0.6, label='Good (<1.0s)')
        ax4.legend(fontsize=10)
        
        # Set reasonable y-axis limits
        max_error = max(errors) if errors else 1.0
        ax4.set_ylim(0, max(1.2, max_error * 1.2))
    else:
        ax4.text(0.5, 0.5, 'No detection results available', 
                ha='center', va='center', transform=ax4.transAxes, fontsize=12)
        ax4.set_title('Detection Accuracy Summary')
    
    plt.tight_layout()
    
    # Save the plot
    plt.savefig('improved_timing_validation.png', dpi=300, bbox_inches='tight')
    print("✓ Plot saved as 'improved_timing_validation.png'")
    
    # Print summary
    print(f"\n{'='*60}")
    print("ENHANCED TIMING DETECTION SUMMARY")
    print(f"{'='*60}")
    
    for layer_name, detected, target, baseline, color in detection_results:
        error = abs(detected - target)
        accuracy = "EXCELLENT" if error < 0.5 else "GOOD" if error < 1.0 else "NEEDS WORK"
        print(f"{layer_name}:")
        print(f"  Target: {target:.1f}s")
        print(f"  Detected: {detected:.1f}s") 
        print(f"  Error: {error:.1f}s ({accuracy})")
        print(f"  Baseline: {baseline:.4f}")
        print()
    
    print("Key Improvements:")
    print("✓ More stable baseline detection (5% final data + stability analysis)")
    print("✓ Sustained completion detection (8+ consecutive points)")
    print("✓ Robust against premature completion (checks for later activity)")
    print("✓ Conservative initiation detection (5 consecutive points above 3x noise)")
    
    plt.show()

if __name__ == "__main__":
    create_improved_timing_plot()
