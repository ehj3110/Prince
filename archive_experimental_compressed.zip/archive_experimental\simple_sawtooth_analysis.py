"""
Improved Timing Analysis
========================

Test the enhanced timing detection against observed completion times:
- Layer 1: should end at ~12.8s
- Layer 2: should end at ~34.1-34.2s
"""

def analyze_improved_timing():
    """Test improved timing detection"""
    
    # Read CSV manually to avoid pandas dependency
    times = []
    forces = []
    positions = []
    
    try:
        with open('autolog_L48-L50.csv', 'r') as f:
            lines = f.readlines()
            for line in lines[1:]:  # Skip header
                parts = line.strip().split(',')
                if len(parts) >= 3:
                    times.append(float(parts[0]))
                    positions.append(float(parts[1]))
                    forces.append(float(parts[2]))
    except Exception as e:
        print(f"Error reading data: {e}")
        return
    
    import numpy as np
    from enhanced_adhesion_metrics import EnhancedAdhesionMetrics
    
    times = np.array(times)
    forces = np.array(forces)
    positions = np.array(positions)
    
    print("Improved Timing Analysis")
    print("=" * 50)
    print(f"Total data points: {len(times)}")
    print(f"Time range: {times.min():.1f} to {times.max():.1f} seconds")
    
    # Create analyzer with improved parameters
    analyzer = EnhancedAdhesionMetrics(noise_threshold=0.04)  # Slightly tighter
    
    # Test individual layers
    layer_segments = [
        ("Layer 1", 0, 800, 12.8),      # Target completion: 12.8s
        ("Layer 2", 800, 1600, 34.1),   # Target completion: 34.1s
        ("Layer 3", 1600, 2200, None)   # No target available
    ]
    
    print(f"\nTarget Completions:")
    print(f"Layer 1: 12.8s")
    print(f"Layer 2: 34.1-34.2s")
    print(f"Layer 3: Unknown (can't see plot)")
    
    for layer_name, start_idx, end_idx, target_completion in layer_segments:
        print(f"\n{layer_name}:")
        print("-" * 30)
        
        # Extract segment
        seg_times = times[start_idx:end_idx]
        seg_positions = positions[start_idx:end_idx]
        seg_forces = forces[start_idx:end_idx]
        
        if len(seg_times) < 20:
            print("Insufficient data")
            continue
        
        # Analyze with enhanced metrics
        try:
            results = analyzer.analyze_peel_event(seg_times, seg_positions, seg_forces)
            
            baseline = results.get('true_baseline', 'Unknown')
            initiation = results.get('peel_initiation_time', 'Unknown')
            peak_time = results.get('peak_force_time', 'Unknown')
            completion = results.get('peel_completion_time', 'Unknown')
            
            print(f"Baseline: {baseline:.4f}")
            print(f"Initiation: {initiation:.1f}s")
            print(f"Peak: {peak_time:.1f}s")
            print(f"Completion: {completion:.1f}s")
            
            # Calculate absolute time
            if completion != 'Unknown':
                absolute_completion = (seg_times[0] - times[0]) + completion
                print(f"Absolute completion: {absolute_completion:.1f}s")
                
                if target_completion is not None:
                    error = abs(absolute_completion - target_completion)
                    print(f"Target: {target_completion:.1f}s")
                    print(f"Error: {error:.1f}s")
                    
                    if error < 0.3:
                        print("✓ EXCELLENT accuracy!")
                    elif error < 0.7:
                        print("✓ Good accuracy")
                    else:
                        print("⚠ Needs improvement")
            
        except Exception as e:
            print(f"Analysis error: {e}")
    
    print(f"\n" + "=" * 50)
    print("BASELINE COMPARISON")
    print("=" * 50)
    
    # Compare baseline across different regions
    regions = [
        ("Start (0-3s)", 0, 100),
        ("Mid L1 (9-12s)", 300, 400),
        ("Between L1-L2", 700, 800),
        ("Mid L2 (30-33s)", 1000, 1100),
        ("Between L2-L3", 1500, 1600),
        ("End (63-66s)", 2100, 2200)
    ]
    
    print("Region baseline analysis:")
    for region_name, start, end in regions:
        if end <= len(forces):
            region_forces = forces[start:end]
            mean_f = np.mean(region_forces)
            std_f = np.std(region_forces)
            print(f"{region_name:15}: {mean_f:.4f} ± {std_f:.4f}")

if __name__ == "__main__":
    analyze_improved_timing()
        
        # Find actual peak in window
        peak_idx = np.argmax(window_forces)
        peak_time = window_times[peak_idx]
        peak_force = window_forces[peak_idx]
        
        print(f"Peak: {peak_force:.6f}N at {peak_time:.3f}s")
        
        # Look for sharp drop after peak
        # Find indices after peak
        post_peak_mask = window_times > peak_time
        post_peak_times = window_times[post_peak_mask]
        post_peak_forces = window_forces[post_peak_mask]
        
        if len(post_peak_forces) > 5:  # Need some data points
            # Calculate force differences between consecutive points
            force_diffs = np.diff(post_peak_forces)
            time_diffs = np.diff(post_peak_times)
            
            # Avoid division by zero
            valid_time_mask = time_diffs > 0
            if np.any(valid_time_mask):
                force_rates = force_diffs[valid_time_mask] / time_diffs[valid_time_mask]
                
                # Find largest negative rate (steepest drop)
                if len(force_rates) > 0 and np.any(force_rates < 0):
                    steepest_drop_idx = np.argmin(force_rates)
                    steepest_drop_rate = force_rates[steepest_drop_idx]
                    steepest_drop_time = post_peak_times[steepest_drop_idx]
                    
                    print(f"Steepest drop: {steepest_drop_rate:.3f} N/s at {steepest_drop_time:.3f}s")
                    
                    # Find continuous drop region around steepest drop
                    # Look for sequence of negative rates
                    negative_mask = force_rates < -0.01  # Significant negative rate
                    if np.any(negative_mask):
                        # Find start of negative region
                        negative_indices = np.where(negative_mask)[0]
                        first_negative = negative_indices[0]
                        last_negative = negative_indices[-1]
                        
                        drop_start_time = post_peak_times[first_negative]
                        drop_end_time = post_peak_times[min(last_negative + 1, len(post_peak_times) - 1)]
                        drop_duration = drop_end_time - drop_start_time
                        
                        drop_start_force = post_peak_forces[first_negative]
                        drop_end_force = post_peak_forces[min(last_negative + 1, len(post_peak_forces) - 1)]
                        force_drop = drop_start_force - drop_end_force
                        
                        print(f"Drop region: {drop_start_time:.3f}s to {drop_end_time:.3f}s")
                        print(f"Drop duration: {drop_duration:.3f}s")
                        print(f"Force drop: {force_drop:.6f}N ({drop_start_force:.6f} → {drop_end_force:.6f}N)")
                        print(f"Quick drop (<0.5s): {drop_duration < 0.5}")
                        
                        # Time from peak to drop start
                        peak_to_drop = drop_start_time - peak_time
                        print(f"Delay from peak to drop: {peak_to_drop:.3f}s")
                    else:
                        print("No significant negative force rates found")
                else:
                    print("No negative force rates found")
            else:
                print("No valid time differences found")
        else:
            print("Insufficient post-peak data")
    
    print("\n" + "=" * 40)
    print("Analysis complete!")

if __name__ == "__main__":
    analyze_sawtooth_pattern()
