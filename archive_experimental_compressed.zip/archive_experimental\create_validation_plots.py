"""
Validation Plot for Corrected Baseline Analysis
=============================================

This script creates comprehensive plots to validate the baseline correction
and improved peel phase detection on your real data.
"""

import numpy as np
import matplotlib.pyplot as plt

def create_validation_plots():
    """Create validation plots showing baseline correction and phase detection"""
    
    # Read the real data
    times = []
    forces = []
    positions = []
    
    with open('example_data.csv', 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:  # Skip header
            parts = line.strip().split(',')
            times.append(float(parts[0]))
            positions.append(float(parts[1]))
            forces.append(float(parts[2]))
    
    times = np.array(times)
    forces = np.array(forces)
    positions = np.array(positions)
    
    print("Creating Validation Plots...")
    print("=" * 40)
    
    # Calculate baseline correction
    final_segment_size = max(10, len(forces) // 10)
    final_segment = forces[-final_segment_size:]
    true_baseline = np.median(final_segment)
    corrected_forces = forces - true_baseline
    
    print(f"Original force range: {forces.min():.6f} to {forces.max():.6f} N")
    print(f"True baseline: {true_baseline:.6f} N")
    print(f"Corrected force range: {corrected_forces.min():.6f} to {corrected_forces.max():.6f} N")
    
    # Define the three peel events with expected timings
    peel_events = [
        {"start": 10, "end": 16, "expected_peel_start": 11.1, "label": "Layer 1", "color": "red"},
        {"start": 30, "end": 38, "expected_peel_start": 32.5, "label": "Layer 2", "color": "green"}, 
        {"start": 52, "end": 60, "expected_peel_start": 55.0, "label": "Layer 3", "color": "blue"}
    ]
    
    # Analyze each peel event
    analysis_results = []
    noise_threshold = 0.003  # Estimated from previous analysis
    
    for event in peel_events:
        # Extract window data
        mask = (times >= event["start"]) & (times <= event["end"])
        window_times = times[mask]
        window_forces = forces[mask]
        window_corrected = corrected_forces[mask]
        window_positions = positions[mask]
        
        if len(window_times) < 5:
            continue
        
        # Find peel initiation (corrected force crosses above baseline)
        positive_mask = window_corrected > (2 * noise_threshold)
        
        if np.any(positive_mask):
            # Find first sustained positive region
            positive_indices = np.where(positive_mask)[0]
            peel_start_idx = positive_indices[0]
            
            # Check for sustained (3+ consecutive points)
            for i in range(len(positive_indices) - 2):
                if (positive_indices[i+1] == positive_indices[i] + 1 and 
                    positive_indices[i+2] == positive_indices[i] + 2):
                    peel_start_idx = positive_indices[i]
                    break
        else:
            peel_start_idx = 0
        
        # Find peak
        peak_idx = np.argmax(window_corrected)
        
        # Find completion (return to baseline after peak)
        post_peak_mask = np.arange(len(window_times)) > peak_idx
        if np.any(post_peak_mask):
            post_peak_corrected = window_corrected[post_peak_mask]
            post_peak_indices = np.arange(len(window_times))[post_peak_mask]
            
            # Find return to baseline
            baseline_return_mask = np.abs(post_peak_corrected) < (2 * noise_threshold)
            
            if np.any(baseline_return_mask):
                baseline_indices = np.where(baseline_return_mask)[0]
                completion_idx = post_peak_indices[baseline_indices[0]]
                
                # Look for sustained return
                for i in range(len(baseline_indices) - 2):
                    if (baseline_indices[i+1] == baseline_indices[i] + 1 and 
                        baseline_indices[i+2] == baseline_indices[i] + 2):
                        completion_idx = post_peak_indices[baseline_indices[i]]
                        break
            else:
                completion_idx = len(window_times) - 1
        else:
            completion_idx = len(window_times) - 1
        
        # Store results
        result = {
            "label": event["label"],
            "color": event["color"],
            "window_start": event["start"],
            "window_end": event["end"],
            "expected_peel_start": event["expected_peel_start"],
            "detected_peel_start": window_times[peel_start_idx],
            "peak_time": window_times[peak_idx],
            "completion_time": window_times[completion_idx],
            "peak_force": window_corrected[peak_idx],
            "peel_duration": window_times[completion_idx] - window_times[peel_start_idx],
            "peak_to_completion": window_times[completion_idx] - window_times[peak_idx]
        }
        analysis_results.append(result)
    
    # Create comprehensive plots
    fig = plt.figure(figsize=(20, 12))
    
    # Plot 1: Full timeline with original vs corrected forces
    ax1 = plt.subplot(2, 3, 1)
    ax1.plot(times, forces, 'k-', alpha=0.7, linewidth=1, label='Original Force')
    ax1.axhline(true_baseline, color='purple', linestyle='--', linewidth=2, label=f'True Baseline ({true_baseline:.6f}N)')
    ax1.axhline(0, color='gray', linestyle='-', alpha=0.5, label='Zero Reference')
    
    # Mark the three peel events
    for result in analysis_results:
        ax1.axvspan(result["window_start"], result["window_end"], alpha=0.2, color=result["color"])
        ax1.text(result["peak_time"], forces.max() * 0.9, result["label"], 
                ha='center', fontweight='bold', color=result["color"])
    
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Force (N)')
    ax1.set_title('Original Forces with Baseline Correction')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Plot 2: Corrected forces
    ax2 = plt.subplot(2, 3, 2)
    ax2.plot(times, corrected_forces, 'b-', alpha=0.7, linewidth=1, label='Baseline-Corrected Force')
    ax2.axhline(0, color='black', linestyle='-', linewidth=2, label='Corrected Baseline (Zero)')
    ax2.axhline(2*noise_threshold, color='orange', linestyle='--', alpha=0.7, label='Peel Detection Threshold')
    ax2.axhline(-2*noise_threshold, color='orange', linestyle='--', alpha=0.7)
    
    # Mark peel phases
    for result in analysis_results:
        ax2.axvspan(result["window_start"], result["window_end"], alpha=0.2, color=result["color"])
        ax2.axvline(result["detected_peel_start"], color=result["color"], linestyle=':', alpha=0.8)
        ax2.axvline(result["peak_time"], color=result["color"], linestyle='-', alpha=0.8)
        ax2.axvline(result["completion_time"], color=result["color"], linestyle=':', alpha=0.8)
    
    ax2.set_xlabel('Time (s)')
    ax2.set_ylabel('Corrected Force (N)')
    ax2.set_title('Baseline-Corrected Forces with Phase Detection')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # Plot 3-5: Individual peel events in detail
    for i, result in enumerate(analysis_results):
        ax = plt.subplot(2, 3, 4 + i)
        
        # Extract detailed window
        detail_start = result["window_start"]
        detail_end = result["window_end"]
        mask = (times >= detail_start) & (times <= detail_end)
        
        detail_times = times[mask]
        detail_original = forces[mask]
        detail_corrected = corrected_forces[mask]
        
        # Plot both original and corrected
        ax.plot(detail_times, detail_original, 'k-', alpha=0.5, linewidth=1, label='Original')
        ax.plot(detail_times, detail_corrected, 'b-', linewidth=2, label='Corrected')
        
        # Mark baseline and thresholds
        ax.axhline(0, color='black', linestyle='-', linewidth=2, alpha=0.7, label='True Baseline')
        ax.axhline(2*noise_threshold, color='orange', linestyle='--', alpha=0.7, label='Detection Threshold')
        ax.axhline(-2*noise_threshold, color='orange', linestyle='--', alpha=0.7)
        
        # Mark phase boundaries
        ax.axvline(result["detected_peel_start"], color='green', linestyle='--', linewidth=2, label='Peel Start')
        ax.axvline(result["peak_time"], color='red', linestyle='--', linewidth=2, label='Peak')
        ax.axvline(result["completion_time"], color='purple', linestyle='--', linewidth=2, label='Completion')
        ax.axvline(result["expected_peel_start"], color='gray', linestyle=':', linewidth=2, label='Expected Start')
        
        # Highlight peel phases
        ax.axvspan(result["detected_peel_start"], result["peak_time"], alpha=0.2, color='green', label='Initiation')
        ax.axvspan(result["peak_time"], result["completion_time"], alpha=0.2, color='red', label='Propagation')
        
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Force (N)')
        ax.set_title(f'{result["label"]} - Detailed Phase Analysis')
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
    
    # Plot 6: Summary comparison
    ax6 = plt.subplot(2, 3, 6)
    
    labels = [r["label"] for r in analysis_results]
    expected_starts = [r["expected_peel_start"] for r in analysis_results]
    detected_starts = [r["detected_peel_start"] for r in analysis_results]
    peak_times = [r["peak_time"] for r in analysis_results]
    completion_times = [r["completion_time"] for r in analysis_results]
    
    x = np.arange(len(labels))
    width = 0.2
    
    ax6.bar(x - width, expected_starts, width, label='Expected Start', alpha=0.7, color='gray')
    ax6.bar(x, detected_starts, width, label='Detected Start', alpha=0.7, color='green')
    ax6.bar(x + width, peak_times, width, label='Peak Time', alpha=0.7, color='red')
    ax6.bar(x + 2*width, completion_times, width, label='Completion', alpha=0.7, color='purple')
    
    ax6.set_xlabel('Layer')
    ax6.set_ylabel('Time (s)')
    ax6.set_title('Timing Comparison: Expected vs Detected')
    ax6.set_xticks(x)
    ax6.set_xticklabels(labels)
    ax6.legend()
    ax6.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('baseline_correction_validation.png', dpi=150, bbox_inches='tight')
    plt.show()
    
    # Print summary results
    print(f"\nVALIDATION RESULTS:")
    print("=" * 50)
    
    for result in analysis_results:
        print(f"\n{result['label']}:")
        print(f"  Expected peel start: {result['expected_peel_start']:.1f}s")
        print(f"  Detected peel start: {result['detected_peel_start']:.1f}s")
        print(f"  Difference: {abs(result['detected_peel_start'] - result['expected_peel_start']):.1f}s")
        print(f"  Peak time: {result['peak_time']:.1f}s")
        print(f"  Completion time: {result['completion_time']:.1f}s")
        print(f"  Total peel duration: {result['peel_duration']:.2f}s")
        print(f"  Peak to completion: {result['peak_to_completion']:.2f}s")
        print(f"  Quick sawtooth (<0.5s): {result['peak_to_completion'] < 0.5}")
        print(f"  Good start detection (<1s diff): {abs(result['detected_peel_start'] - result['expected_peel_start']) < 1.0}")
    
    print(f"\nKEY IMPROVEMENTS:")
    print("✓ Post-separation baseline correction applied")
    print("✓ Peel initiation at force crossing baseline (not gradient)")
    print("✓ Completion at return to baseline (not arbitrary threshold)")
    print("✓ Physics-based three-phase detection")
    
    return analysis_results

if __name__ == "__main__":
    results = create_validation_plots()
    print(f"\nValidation plot saved as: baseline_correction_validation.png")
