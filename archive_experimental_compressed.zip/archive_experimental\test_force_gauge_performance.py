"""
Force Gauge High-Frequency Sampling Test

This script tests the improved force gauge sampling capabilities
and measures performance without interfering with DLP operations.
"""

import time
import threading
import queue
import sys
import os

# Add the current directory to sys.path to import project modules
sys.path.append(os.path.dirname(__file__))

try:
    from ForceGaugeManager import ForceGaugeManager
    from USBCoordinator import usb_coordinator
    DEPENDENCIES_AVAILABLE = True
except ImportError as e:
    print(f"Could not import required modules: {e}")
    print("This test requires ForceGaugeManager and USBCoordinator")
    DEPENDENCIES_AVAILABLE = False

class MockLabel:
    """Mock Tkinter label for testing without GUI."""
    def __init__(self, initial_text=""):
        self.text = initial_text
    
    def config(self, text=""):
        self.text = text
        
    def get_text(self):
        return self.text

class ForceGaugePerformanceTest:
    def __init__(self):
        self.test_duration = 30  # seconds
        self.data_points_received = 0
        self.start_time = None
        self.end_time = None
        self.force_data_queue = queue.Queue()
        self.mock_labels = {
            'gain': MockLabel("Gain: Testing"),
            'offset': MockLabel("Offset: Testing"),
            'status': MockLabel("Status: Testing"),
            'large_readout': MockLabel("Force: Testing")
        }
        
    def run_performance_test(self):
        """Run a comprehensive performance test of the force gauge."""
        print("="*60)
        print("FORCE GAUGE HIGH-FREQUENCY SAMPLING TEST")
        print("="*60)
        
        if not DEPENDENCIES_AVAILABLE:
            print("❌ Required dependencies not available")
            return False
            
        print("📊 Initializing force gauge manager...")
        
        try:
            # Initialize ForceGaugeManager with mock components
            force_manager = ForceGaugeManager(
                gain_label=self.mock_labels['gain'],
                offset_label=self.mock_labels['offset'],
                force_status_label=self.mock_labels['status'],
                large_force_readout_label=self.mock_labels['large_readout'],
                output_force_queue=self.force_data_queue,
                parent_window=None,
                sensor_window_ref=None
            )
            
            print("✅ Force gauge manager initialized")
            
        except Exception as e:
            print(f"❌ Failed to initialize force gauge: {e}")
            return False
        
        # Test 1: Hardware Configuration Check
        print("\n🔧 Testing hardware configuration...")
        try:
            # Check if Phidget is properly configured for high-speed sampling
            if hasattr(force_manager, 'voltage_ratio_input') and force_manager.voltage_ratio_input:
                print("✅ Phidget device detected")
                
                # Try to get current data interval
                if hasattr(force_manager.voltage_ratio_input, 'getDataInterval'):
                    current_interval = force_manager.voltage_ratio_input.getDataInterval()
                    expected_rate = 1000 / current_interval
                    print(f"📈 Current sampling rate: {expected_rate:.1f} Hz ({current_interval}ms interval)")
                    
                    if current_interval <= 10:
                        print("✅ High-speed sampling configured (≥100Hz)")
                    else:
                        print("⚠️  Sampling rate could be improved")
                        
            else:
                print("❌ Phidget device not properly initialized")
                return False
                
        except Exception as e:
            print(f"⚠️  Could not check hardware config: {e}")
        
        # Test 2: USB Coordinator Integration
        print("\n🚦 Testing USB coordination...")
        try:
            stats = usb_coordinator.get_stats()
            print(f"📊 USB Coordinator stats: {stats}")
            
            # Simulate a DLP operation to test coordination
            print("🎬 Simulating DLP operation...")
            with usb_coordinator.dlp_operation("test_operation"):
                time.sleep(0.1)  # Simulate DLP command
                
            print("✅ USB coordination working")
            
        except Exception as e:
            print(f"⚠️  USB coordination test failed: {e}")
        
        # Test 3: Data Collection Performance
        print(f"\n⏱️  Starting {self.test_duration}s data collection test...")
        
        self.start_time = time.time()
        end_test_time = self.start_time + self.test_duration
        
        # Monitor data collection
        last_report_time = self.start_time
        report_interval = 5  # Report every 5 seconds
        
        while time.time() < end_test_time:
            current_time = time.time()
            
            # Count data points in queue
            try:
                while True:
                    self.force_data_queue.get_nowait()
                    self.data_points_received += 1
            except queue.Empty:
                pass
            
            # Periodic progress report
            if current_time - last_report_time >= report_interval:
                elapsed = current_time - self.start_time
                rate = self.data_points_received / elapsed if elapsed > 0 else 0
                print(f"📈 {elapsed:.1f}s elapsed: {self.data_points_received} data points ({rate:.1f} Hz)")
                last_report_time = current_time
                
                # Check buffer statistics
                if hasattr(force_manager, 'get_buffer_stats'):
                    buffer_stats = force_manager.get_buffer_stats()
                    print(f"   Buffer: {buffer_stats['length']} points, {buffer_stats['rate_hz']:.1f} Hz")
            
            time.sleep(0.1)  # Small delay to prevent busy waiting
        
        self.end_time = time.time()
        
        # Test 4: Performance Analysis
        print("\n📊 PERFORMANCE ANALYSIS")
        print("-" * 30)
        
        total_time = self.end_time - self.start_time
        average_rate = self.data_points_received / total_time
        
        print(f"⏱️  Test duration: {total_time:.2f} seconds")
        print(f"📦 Total data points: {self.data_points_received}")
        print(f"📈 Average sampling rate: {average_rate:.2f} Hz")
        
        # Performance benchmarks
        if average_rate >= 100:
            print("🎯 EXCELLENT: Achieved high-frequency sampling (≥100Hz)")
        elif average_rate >= 50:
            print("✅ GOOD: Decent sampling rate (≥50Hz)")
        elif average_rate >= 25:
            print("⚠️  FAIR: Moderate sampling rate (≥25Hz)")
        else:
            print("❌ POOR: Low sampling rate (<25Hz)")
        
        # Buffer performance
        if hasattr(force_manager, 'get_buffer_stats'):
            final_buffer_stats = force_manager.get_buffer_stats()
            print(f"📦 Final buffer: {final_buffer_stats['length']} points")
            print(f"📈 Buffer rate: {final_buffer_stats['rate_hz']:.2f} Hz")
            
            if final_buffer_stats['rate_hz'] > average_rate * 1.5:
                print("⚡ Buffer capturing faster than queue processing - good!")
        
        # USB coordination stats
        final_usb_stats = usb_coordinator.get_stats()
        print(f"🚦 USB operations: DLP={final_usb_stats['dlp_operations']}, "
              f"Phidget={final_usb_stats['phidget_operations']}, "
              f"Conflicts prevented={final_usb_stats['conflicts_prevented']}")
        
        # Test 5: Cleanup
        print("\n🧹 Cleaning up...")
        try:
            if hasattr(force_manager, 'close_phidget'):
                force_manager.close_phidget()
            print("✅ Cleanup completed")
        except Exception as e:
            print(f"⚠️  Cleanup warning: {e}")
        
        print("\n" + "="*60)
        if average_rate >= 50:
            print("🎉 HIGH-FREQUENCY SAMPLING TEST PASSED")
        else:
            print("⚠️  TEST COMPLETED WITH ISSUES")
        print("="*60)
        
        return average_rate >= 50

def main():
    """Main test function."""
    test = ForceGaugePerformanceTest()
    success = test.run_performance_test()
    
    if success:
        print("\n💡 Recommendations:")
        print("   - Force gauge is ready for high-frequency data collection")
        print("   - DLP operations should be properly coordinated")
        print("   - Consider further optimizations if you need >100Hz")
    else:
        print("\n🔧 Troubleshooting suggestions:")
        print("   - Check Phidget hardware connections")
        print("   - Verify Phidget22 library installation")
        print("   - Ensure no other software is using the force gauge")
        print("   - Try reducing GUI update frequency")
    
    return success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
