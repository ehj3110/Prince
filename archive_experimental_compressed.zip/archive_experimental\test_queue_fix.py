"""
Test script to verify the force queue data format fix.
This simulates the data flow between ForceGaugeManager and PositionLogger.
"""

import queue
import time

def test_force_queue_format():
    """Test that PositionLogger can handle the new force queue format"""
    print("Testing Force Queue Data Format Fix")
    print("===================================")
    
    # Create a test queue (simulating the output_force_queue)
    test_queue = queue.Queue()
    
    # Simulate ForceGaugeManager sending data in new format
    test_data = [
        ("force_calibrated", 1.234),
        ("force_calibrated", 2.456),
        ("voltage_ratio_uncalibrated", 0.00012345),
        ("force_calibrated", 3.789),
    ]
    
    print("Simulating ForceGaugeManager sending data...")
    for data_type, value in test_data:
        test_queue.put((data_type, value))
        print(f"  Sent: {(data_type, value)}")
    
    # Simulate PositionLogger processing the queue
    print("\nSimulating PositionLogger processing data...")
    latest_force_value_for_log = 0.0
    
    try:
        while not test_queue.empty():
            queue_item = test_queue.get_nowait()
            print(f"  Received: {queue_item}")
            
            # Use the same logic as the updated PositionLogger
            if isinstance(queue_item, tuple) and len(queue_item) == 2:
                data_type, value = queue_item
                if isinstance(data_type, str) and 'force' in data_type.lower():
                    latest_force_value_for_log = value
                    print(f"    → Updated force value to: {latest_force_value_for_log}")
                else:
                    print(f"    → Ignored non-force data: {data_type}")
            elif isinstance(queue_item, (int, float)):
                # Handle legacy format
                latest_force_value_for_log = queue_item
                print(f"    → Updated force value (legacy format): {latest_force_value_for_log}")
            else:
                print(f"    → Unexpected format: {type(queue_item)}")
                
    except queue.Empty:
        print("  Queue is empty")
    except Exception as e:
        print(f"  Error: {e}")
        return False
    
    print(f"\nFinal force value: {latest_force_value_for_log}")
    
    # Test legacy format compatibility
    print("\nTesting legacy format compatibility...")
    legacy_queue = queue.Queue()
    legacy_queue.put(5.678)  # Old format: just the float value
    
    try:
        queue_item = legacy_queue.get_nowait()
        print(f"  Received legacy format: {queue_item}")
        
        if isinstance(queue_item, (int, float)):
            latest_force_value_for_log = queue_item
            print(f"    → Updated force value (legacy): {latest_force_value_for_log}")
        
    except Exception as e:
        print(f"  Legacy format failed: {e}")
        return False
    
    print(f"Final force value after legacy test: {latest_force_value_for_log}")
    print("\n✓ All tests passed! The fix should work correctly.")
    return True

if __name__ == "__main__":
    success = test_force_queue_format()
    if success:
        print("\nThe PositionLogger error should be fixed.")
        print("You can now use the sensor panel without the unpacking error.")
    else:
        print("\nSome tests failed. Please check the implementation.")
