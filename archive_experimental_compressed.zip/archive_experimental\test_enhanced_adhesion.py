"""
Test script for Enhanced PeakForceLogger
=========================================

This script tests the enhanced PeakForceLogger with both original and enhanced analysis modes.
"""

import numpy as np
import time
from PeakForceLogger import PeakForceLogger

def test_enhanced_peak_force_logger():
    """Test the enhanced PeakForceLogger functionality."""
    print("Testing Enhanced PeakForceLogger")
    print("=" * 50)
    
    # Test 1: Enhanced analysis mode
    print("\n1. Testing Enhanced Analysis Mode")
    logger_enhanced = PeakForceLogger("test_enhanced_adhesion.csv", is_manual_log=False, enhanced_analysis=True)
    
    # Simulate realistic peeling data
    current_time = time.time()
    logger_enhanced.start_monitoring_for_layer(1, z_peel_peak=10.0, z_return_pos=12.0)
    
    # Add realistic force curve data
    positions = np.linspace(9.8, 12.2, 50)
    times = np.linspace(current_time, current_time + 2.0, 50)
    
    for i, (t, pos) in enumerate(zip(times, positions)):
        # Create realistic force profile
        if pos < 10.0:
            force = 0.01 + np.random.normal(0, 0.002)  # Baseline noise
        elif pos < 10.5:
            force = 0.01 + 0.3 * (pos - 10.0)  # Loading
        elif pos < 11.0:
            force = 0.16 + 0.1 * (pos - 10.5)  # Peak region
        elif pos < 11.5:
            force = 0.21 - 0.25 * (pos - 11.0)  # Unloading
        else:
            force = max(0.08 - 0.1 * (pos - 11.5), 0.005)  # Return to baseline
            
        force += np.random.normal(0, 0.005)  # Add realistic noise
        logger_enhanced.add_data_point(t, pos, force)
    
    # Stop monitoring and analyze
    success = logger_enhanced.stop_monitoring_and_log_peak()
    print(f"Enhanced analysis completed: {success}")
    
    # Test 2: Original analysis mode for comparison
    print("\n2. Testing Original Analysis Mode")
    logger_original = PeakForceLogger("test_original_adhesion.csv", is_manual_log=False, enhanced_analysis=False)
    
    logger_original.start_monitoring_for_layer(1, z_peel_peak=10.0, z_return_pos=12.0)
    
    # Add the same data
    for i, (t, pos) in enumerate(zip(times, positions)):
        if pos < 10.0:
            force = 0.01 + np.random.normal(0, 0.002)
        elif pos < 10.5:
            force = 0.01 + 0.3 * (pos - 10.0)
        elif pos < 11.0:
            force = 0.16 + 0.1 * (pos - 10.5)
        elif pos < 11.5:
            force = 0.21 - 0.25 * (pos - 11.0)
        else:
            force = max(0.08 - 0.1 * (pos - 11.5), 0.005)
            
        force += np.random.normal(0, 0.005)
        logger_original.add_data_point(t, pos, force)
    
    success = logger_original.stop_monitoring_and_log_peak()
    print(f"Original analysis completed: {success}")
    
    # Test 3: Manual log mode
    print("\n3. Testing Manual Log Mode")
    logger_manual = PeakForceLogger("test_manual_adhesion.csv", is_manual_log=True, enhanced_analysis=True)
    
    logger_manual.start_monitoring_for_layer(0)  # No specific peel range for manual
    
    # Add some manual data
    manual_times = np.linspace(current_time, current_time + 1.0, 20)
    manual_positions = np.linspace(15.0, 17.0, 20)
    
    for t, pos in zip(manual_times, manual_positions):
        force = 0.05 + 0.15 * np.sin(3 * (pos - 15.0)) + np.random.normal(0, 0.01)
        force = max(force, 0)
        logger_manual.add_data_point(t, pos, force)
    
    success = logger_manual.stop_monitoring_and_log_peak()
    print(f"Manual log completed: {success}")
    
    print("\n" + "=" * 50)
    print("Test completed! Check the following files:")
    print("- test_enhanced_adhesion.csv (Enhanced metrics)")
    print("- test_original_adhesion.csv (Original metrics)")
    print("- test_manual_adhesion.csv (Manual log with timestamp)")

if __name__ == "__main__":
    test_enhanced_peak_force_logger()
