import time
import traceback
import queue
import threading
import tkinter
from concurrent.futures import ThreadPoolExecutor
from tkinter import messagebox, simpledialog
from Phidget22.Phidget import *
from Phidget22.Devices.VoltageRatioInput import *
from Phidget22.Devices.VoltageInput import *
from Phidget22.Net import *
from Phidget22.PhidgetException import PhidgetException
from Phidget22.ErrorCode import ErrorCode
from Phidget22.BridgeGain import BridgeGain

class ForceGaugeManager:
    def __init__(self, gain_label, offset_label, force_status_label, large_force_readout_label, output_force_queue, parent_window, sensor_window_ref):
        self.gain_label = gain_label
        self.offset_label = offset_label
        self.force_status_label = force_status_label
        self.large_force_readout_label = large_force_readout_label
        self.output_force_queue = output_force_queue
        self.parent_window = parent_window
        self.sensor_window_ref = sensor_window_ref

        self.GAIN = None
        self.OFFSET = None
        self.voltage_ratio_input = None  # Back to voltage_ratio_input as per sample code
        self.latest_calibrated_force = 0.0 # Initialize to a default float value
        self.calibrated_once = False
        
        # High-frequency force logging support
        self.peak_force_logger = None  # Will be set by SensorDataWindow
        self.last_position = None  # Cache last known position for high-freq logging
        
        # Multi-threading support for data processing
        self._data_processing_executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="ForceData")
        self._critical_data_queue = queue.Queue(maxsize=10000)  # Large queue for critical data
        self._gui_update_queue = queue.Queue(maxsize=100)  # Smaller queue for GUI updates
        
        # Performance monitoring
        self._data_points_received = 0
        self._data_points_processed = 0
        self._last_performance_report = time.time()
        
        # Critical operations thread
        self._critical_thread_running = True
        self._critical_data_thread = threading.Thread(target=self._process_critical_data, daemon=True)
        self._critical_data_thread.start()
        
        # GUI update thread (lower priority)
        self._gui_update_thread = threading.Thread(target=self._process_gui_updates, daemon=True)
        self._gui_update_thread.start()
        
        self.initialize_phidget()

    def initialize_phidget(self):
        try:
            # Disable Phidget logging to avoid potential DLP conflicts
            print("Phidget logging disabled to prevent DLP conflicts")
            
            print("Initializing VoltageRatioInput for PhidgetBridge (ForceGaugeManager)...")
            self.voltage_ratio_input = VoltageRatioInput()  # Back to VoltageRatioInput as per sample
            
            # Set channel 2 since that's where the load cell is connected
            print("Setting channel to 2 (load cell connection)...")
            self.voltage_ratio_input.setChannel(2)
            
            # Set event handlers before opening (as shown in sample)
            self.voltage_ratio_input.setOnVoltageRatioChangeHandler(self._onVoltageRatioChange)
            self.voltage_ratio_input.setOnAttachHandler(self._onAttach)
            self.voltage_ratio_input.setOnDetachHandler(self._onDetach)
            self.voltage_ratio_input.setOnErrorHandler(self._onError)
            
            # Open and wait for attachment (using same timeout as sample)
            print("Opening connection...")
            self.voltage_ratio_input.openWaitForAttachment(5000)
            
            # Set initial data interval - will be updated by SensorDataWindow based on sampling rate
            # Start with a moderate rate, user can adjust via sampling rate box
            try:
                self.voltage_ratio_input.setDataInterval(25)  # Default: 25ms (40 Hz)
                print("Phidget data interval initialized to 25ms (40 Hz) - will sync with sampling rate setting")
            except Exception as e:
                print(f"Could not set initial data interval: {e}")
                # Try 50ms if 25ms fails
                try:
                    self.voltage_ratio_input.setDataInterval(50)  # 50ms fallback (20 Hz)
                    print("Phidget data interval set to 50ms (20 Hz) (fallback)")
                except Exception as e2:
                    print(f"Could not set any initial data interval: {e2}")
            
            print("PhidgetBridge connected successfully (ForceGaugeManager)!")
        except PhidgetException as ex:
            # Handle as shown in sample code
            traceback.print_exc()
            print("")
            print(f"PhidgetException {str(ex.code)} ({ex.description}): {ex.details}")
            if ex.code == ErrorCode.EPHIDGET_TIMEOUT:
                print("PhidgetBridge connection timed out - device may not be connected.")
                messagebox.showwarning("Phidget Warning", "PhidgetBridge device not found. Force gauge functionality will be limited until device is connected.", parent=self.parent_window)
            else:
                messagebox.showerror("Phidget Error", f"PhidgetException {ex.code} ({ex.description}): {ex.details}", parent=self.parent_window)
            self.voltage_ratio_input = None  # Ensure it's None if connection failed
        except Exception as e:
            traceback.print_exc()
            print(f"Unexpected error in initialize_phidget (ForceGaugeManager): {e}")
            messagebox.showerror("Phidget Error", f"Unexpected error initializing Phidget: {e}", parent=self.parent_window)
            self.voltage_ratio_input = None  # Ensure it's None if connection failed

    def _onAttach(self, phidget):
        print(f"PhidgetBridge attached (ForceGaugeManager): Serial {phidget.getDeviceSerialNumber()}")

    def _onDetach(self, phidget):
        print(f"PhidgetBridge detached (ForceGaugeManager): {phidget}")

    def _onError(self, phidget, error_code, error_string):
        print(f"PhidgetBridge error (ForceGaugeManager): {error_code} - {error_string}")
        # Potentially show a messagebox or update a status label

    def _onVoltageRatioChange(self, phidget, voltageRatio):
        """
        Optimized event handler for high-frequency data processing.
        Minimizes operations in the event handler itself.
        """
        try:
            self._data_points_received += 1
            
            if self.calibrated_once and self.GAIN is not None and self.OFFSET is not None:
                # CRITICAL: Fast force calculation (prioritize data integrity)
                force = (voltageRatio - self.OFFSET) / self.GAIN
                current_time = time.time()
                
                try:
                    # Put critical data in high-priority queue (non-blocking)
                    self._critical_data_queue.put_nowait((current_time, force))
                except queue.Full:
                    # If critical queue is full, force data through by dropping oldest
                    try:
                        self._critical_data_queue.get_nowait()  # Drop oldest
                        self._critical_data_queue.put_nowait((current_time, force))  # Add new
                    except queue.Empty:
                        pass
                
                # LOWER PRIORITY: Queue GUI updates (drop if queue full)
                # Only update GUI every 25 readings to reduce overhead
                if not hasattr(self, '_gui_counter'):
                    self._gui_counter = 0
                self._gui_counter += 1
                
                if self._gui_counter >= 25:  # Update GUI every 25 readings
                    self._gui_counter = 0
                    try:
                        self._gui_update_queue.put_nowait(force)
                    except queue.Full:
                        # Drop GUI updates if queue is full - data is more important
                        pass
                
                # Performance monitoring (minimal overhead)
                if current_time - self._last_performance_report > 5.0:  # Report every 5 seconds
                    rate = self._data_points_received / (current_time - self._last_performance_report)
                    print(f"Force data rate: {rate:.1f} Hz, Processed: {self._data_points_processed}")
                    self._last_performance_report = current_time
                    self._data_points_received = 0
                    self._data_points_processed = 0
                    
            else:
                # Handle uncalibrated state with minimal processing
                self.latest_calibrated_force = 0.0
                # Only update GUI occasionally when uncalibrated
                if not hasattr(self, '_uncalibrated_counter'):
                    self._uncalibrated_counter = 0
                self._uncalibrated_counter += 1
                
                if self._uncalibrated_counter >= 100:  # Very infrequent updates
                    self._uncalibrated_counter = 0
                    voltage_ratio_text = f"VoltageRatio: {voltageRatio:.8f} (Calibration needed)"
                    try:
                        self._gui_update_queue.put_nowait(voltage_ratio_text)
                    except queue.Full:
                        pass
                        
        except Exception as e:
            # Minimal error handling to avoid slowing down the event handler
            self.latest_calibrated_force = 0.0

    def get_latest_calibrated_force(self):
        """Returns the latest calibrated force reading."""
        return self.latest_calibrated_force

    def calibrate_force_gauge(self):
        """Interactive calibration process for the force gauge."""
        if not self.voltage_ratio_input or not self.voltage_ratio_input.getAttached():
            messagebox.showerror("Error", "PhidgetBridge not connected. Cannot calibrate.", parent=self.parent_window)
            return

        print("Starting force gauge calibration...")
        
        # 1. Zero load calibration
        messagebox.showinfo("Calibration Step 1", "Remove all load from the force gauge and press OK when ready.", parent=self.parent_window)
        time.sleep(1)  # Give a moment for the sensor to stabilize
        
        zero_readings = []
        for i in range(50):  # Take 50 readings for averaging
            try:
                voltage_ratio = self.voltage_ratio_input.getVoltageRatio()
                zero_readings.append(voltage_ratio)
                time.sleep(0.02)  # 20ms between readings
            except Exception as e:
                print(f"Error reading voltage ratio during zero calibration: {e}")
        
        if not zero_readings:
            messagebox.showerror("Error", "Could not read voltage ratio for zero calibration.", parent=self.parent_window)
            return
        
        zero_voltage_ratio = sum(zero_readings) / len(zero_readings)
        print(f"Zero load voltage ratio: {zero_voltage_ratio:.8f}")
        
        # 2. Known load calibration
        known_force = simpledialog.askfloat("Calibration Step 2", "Apply a known force to the gauge.\nEnter the known force value in Newtons:", parent=self.parent_window)
        if known_force is None or known_force <= 0:
            messagebox.showerror("Error", "Invalid known force value. Calibration cancelled.", parent=self.parent_window)
            return
        
        messagebox.showinfo("Calibration Step 2", f"Apply the {known_force} N force to the gauge and press OK when stable.", parent=self.parent_window)
        time.sleep(1)  # Give a moment for the sensor to stabilize
        
        loaded_readings = []
        for i in range(50):  # Take 50 readings for averaging
            try:
                voltage_ratio = self.voltage_ratio_input.getVoltageRatio()
                loaded_readings.append(voltage_ratio)
                time.sleep(0.02)  # 20ms between readings
            except Exception as e:
                print(f"Error reading voltage ratio during loaded calibration: {e}")
        
        if not loaded_readings:
            messagebox.showerror("Error", "Could not read voltage ratio for loaded calibration.", parent=self.parent_window)
            return
        
        loaded_voltage_ratio = sum(loaded_readings) / len(loaded_readings)
        print(f"Loaded voltage ratio: {loaded_voltage_ratio:.8f}")
        
        # 3. Calculate calibration constants
        if abs(loaded_voltage_ratio - zero_voltage_ratio) < 1e-9:
            messagebox.showerror("Error", "No significant change in voltage ratio. Check the applied force and try again.", parent=self.parent_window)
            return
        
        self.GAIN = (loaded_voltage_ratio - zero_voltage_ratio) / known_force
        self.OFFSET = zero_voltage_ratio
        
        print(f"Calibration completed. GAIN: {self.GAIN:.8f}, OFFSET: {self.OFFSET:.8f}")
        
        # Update labels
        self.gain_label.config(text=f"Gain: {self.GAIN:.8f}")
        self.offset_label.config(text=f"Offset: {self.OFFSET:.8f}")
        
        self.calibrated_once = True
        if self.sensor_window_ref:
            self.sensor_window_ref.update_calibration_status_for_main_app(True)
        
        messagebox.showinfo("Calibration Complete", f"Force gauge calibrated successfully.\nGain: {self.GAIN:.8f}\nOffset: {self.OFFSET:.8f}", parent=self.parent_window)

    def quick_calibrate_force_gauge(self, calibration_source="unknown"):
        """Quick calibration using stored gain and offset values."""
        default_gain = 1.33e-5  # Default value as specified
        default_offset = 0.0
        
        # Get calibration values from user
        gain = simpledialog.askfloat("Quick Calibration", f"Enter GAIN value (default: {default_gain}):", initialvalue=default_gain, parent=self.parent_window)
        if gain is None:
            return  # User cancelled
        
        offset = simpledialog.askfloat("Quick Calibration", f"Enter OFFSET value (default: {default_offset}):", initialvalue=default_offset, parent=self.parent_window)
        if offset is None:
            return  # User cancelled
        
        self.GAIN = gain
        self.OFFSET = offset
        
        # Update labels
        self.gain_label.config(text=f"Gain: {self.GAIN:.8f}")
        self.offset_label.config(text=f"Offset: {self.OFFSET:.8f}")
        
        self.calibrated_once = True
        if self.sensor_window_ref:
            self.sensor_window_ref.update_calibration_status_for_main_app(True)
        
        print(f"Quick calibration applied (ForceGaugeManager) from {calibration_source}. GAIN: {self.GAIN:.4f}, OFFSET: {self.OFFSET:.8f}")
        messagebox.showinfo("Quick Calibration", f"Calibration values applied from {calibration_source}.\nGain: {self.GAIN:.4f}\nOffset: {self.OFFSET:.8f}", parent=self.parent_window)

    def set_data_interval(self, interval_ms):
        """Set the Phidget data interval (how often it sends data)."""
        try:
            if self.voltage_ratio_input and self.voltage_ratio_input.getAttached():
                self.voltage_ratio_input.setDataInterval(interval_ms)
                print(f"Phidget data interval updated to {interval_ms}ms")
                return True
            else:
                print("Cannot set data interval: Phidget not connected")
                return False
        except Exception as e:
            print(f"Error setting Phidget data interval: {e}")
            return False

    def stop_force_reading_thread(self):
        """Stops the force reading by closing the Phidget device."""
        print("ForceGaugeManager: stop_force_reading_thread called, invoking close_phidget.")
        self.close_phidget()

    def close_phidget(self):
        print("Closing Phidget connection (ForceGaugeManager)...")
        
        # Signal threads to stop
        self._critical_thread_running = False
        
        # Wait for threads to finish (with timeout)
        if self._critical_data_thread and self._critical_data_thread.is_alive():
            self._critical_data_thread.join(timeout=2.0)
            if self._critical_data_thread.is_alive():
                print("Warning: Critical data thread did not stop cleanly")
        
        if self._gui_update_thread and self._gui_update_thread.is_alive():
            self._gui_update_thread.join(timeout=2.0)
            if self._gui_update_thread.is_alive():
                print("Warning: GUI update thread did not stop cleanly")
        
        # Shutdown thread pool
        if self._data_processing_executor:
            self._data_processing_executor.shutdown(wait=True)
        
        # Close Phidget device
        if self.voltage_ratio_input:
            try:
                print("Closing VoltageRatioInput...")
                self.voltage_ratio_input.close()
                print("VoltageRatioInput closed.")
            except Exception as e:
                print(f"Error closing VoltageRatioInput: {e}")
            finally:
                self.voltage_ratio_input = None
        
        print("ForceGaugeManager cleanup completed.")

    def _process_critical_data(self):
        """
        High-priority thread for processing critical force data.
        This handles PeakForceLogger and data logging with priority.
        """
        while self._critical_thread_running:
            try:
                # Get critical data with timeout
                timestamp, force = self._critical_data_queue.get(timeout=0.5)
                
                # Check if we're still supposed to be running
                if not self._critical_thread_running:
                    break
                
                # HIGH PRIORITY: Update PeakForceLogger (critical for data integrity)
                if self.peak_force_logger:
                    try:
                        current_position = self.last_position
                        if current_position is not None:
                            self.peak_force_logger.log_force_and_position(force, current_position, timestamp)
                        else:
                            # Log force without position if position is not available
                            self.peak_force_logger.log_force_and_position(force, 0.0, timestamp)
                    except Exception as pfl_error:
                        print(f"Error in PeakForceLogger: {pfl_error}")
                
                # HIGH PRIORITY: Queue force data for output (to any connected loggers)
                try:
                    self.output_force_queue.put_nowait(force)
                except queue.Full:
                    # If output queue is full, force data through by dropping oldest
                    try:
                        self.output_force_queue.get_nowait()  # Drop oldest
                        self.output_force_queue.put_nowait(force)  # Add new
                    except queue.Empty:
                        pass
                
                # Update latest calibrated force (thread-safe)
                self.latest_calibrated_force = force
                
                # Performance tracking
                self._data_points_processed += 1
                
                self._critical_data_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Error in critical data processing: {e}")
                continue

    def _process_gui_updates(self):
        """
        Lower-priority thread for GUI updates.
        This can be slower without affecting data integrity.
        """
        while self._critical_thread_running:
            try:
                # Process GUI updates with longer timeout (less critical)
                force = self._gui_update_queue.get(timeout=0.5)
                
                # Check if we're still supposed to be running
                if not self._critical_thread_running:
                    break
                
                # Update GUI labels (lower priority) with safety checks
                current_force_text = f"Force: {force:.6f} N"
                
                # Safe GUI updates - check if widgets still exist
                self._safe_update_label(self.force_status_label, current_force_text)
                self._safe_update_label(self.large_force_readout_label, current_force_text)
                
                self._gui_update_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                # Don't print GUI errors too frequently - just continue
                continue

    def _safe_update_label(self, label, text):
        """Safely update a label, handling cases where widget is destroyed."""
        if label is None:
            return
            
        try:
            # Check if widget still exists
            if label.winfo_exists():
                label.after_idle(lambda: self._do_safe_label_config(label, text))
        except (AttributeError, tkinter.TclError):
            # Widget destroyed or doesn't exist - stop trying to update it
            label = None

    def _do_safe_label_config(self, label, text):
        """Perform the actual label configuration with error handling."""
        try:
            if label and label.winfo_exists():
                label.config(text=text)
        except (AttributeError, tkinter.TclError):
            # Widget no longer exists - ignore silently
            pass
