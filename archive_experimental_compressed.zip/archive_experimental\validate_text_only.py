"""
Simple Validation Output for Baseline Correction
===============================================

This script validates the baseline correction and phase detection
with text output only (no plotting issues).
"""

import numpy as np

def validate_baseline_correction():
    """Validate the corrected baseline analysis with text output"""
    
    # Read the real data
    times = []
    forces = []
    positions = []
    
    with open('example_data.csv', 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:  # Skip header
            parts = line.strip().split(',')
            times.append(float(parts[0]))
            positions.append(float(parts[1]))
            forces.append(float(parts[2]))
    
    times = np.array(times)
    forces = np.array(forces)
    positions = np.array(positions)
    
    print("BASELINE CORRECTION VALIDATION")
    print("=" * 50)
    
    # Calculate baseline correction
    final_segment_size = max(10, len(forces) // 10)
    final_segment = forces[-final_segment_size:]
    true_baseline = np.median(final_segment)
    corrected_forces = forces - true_baseline
    
    print(f"Data Summary:")
    print(f"  Total data points: {len(times)}")
    print(f"  Time range: {times.min():.3f} to {times.max():.3f} seconds")
    print(f"  Original force range: {forces.min():.6f} to {forces.max():.6f} N")
    print(f"  True baseline (post-separation): {true_baseline:.6f} N")
    print(f"  Corrected force range: {corrected_forces.min():.6f} to {corrected_forces.max():.6f} N")
    
    # Estimate noise level
    initial_segment = forces[:50]  # First 50 points
    noise_estimate = np.std(initial_segment)
    print(f"  Estimated noise level: {noise_estimate:.6f} N")
    
    # Define the three peel events with your expected timings
    peel_events = [
        {"start": 10, "end": 16, "expected_peel_start": 11.1, "label": "Layer 1"},
        {"start": 30, "end": 38, "expected_peel_start": 32.5, "label": "Layer 2"}, 
        {"start": 52, "end": 60, "expected_peel_start": 55.0, "label": "Layer 3"}
    ]
    
    noise_threshold = 0.003  # Conservative noise threshold
    
    print(f"\nPEEL EVENT ANALYSIS:")
    print("=" * 50)
    
    for event in peel_events:
        print(f"\n{event['label']} ({event['start']}-{event['end']}s):")
        print("-" * 30)
        
        # Extract window data
        mask = (times >= event["start"]) & (times <= event["end"])
        window_times = times[mask]
        window_forces = forces[mask]
        window_corrected = corrected_forces[mask]
        window_positions = positions[mask]
        
        if len(window_times) < 5:
            print("  Insufficient data in window")
            continue
        
        print(f"  Window data points: {len(window_times)}")
        print(f"  Original force range: {window_forces.min():.6f} to {window_forces.max():.6f} N")
        print(f"  Corrected force range: {window_corrected.min():.6f} to {window_corrected.max():.6f} N")
        
        # Find peel initiation (corrected force crosses above baseline)
        positive_mask = window_corrected > (2 * noise_threshold)
        
        if np.any(positive_mask):
            positive_indices = np.where(positive_mask)[0]
            peel_start_idx = positive_indices[0]
            
            # Look for sustained positive force (3+ consecutive points)
            for i in range(len(positive_indices) - 2):
                if (positive_indices[i+1] == positive_indices[i] + 1 and 
                    positive_indices[i+2] == positive_indices[i] + 2):
                    peel_start_idx = positive_indices[i]
                    break
                    
            detected_peel_start = window_times[peel_start_idx]
            peel_start_force = window_corrected[peel_start_idx]
        else:
            detected_peel_start = window_times[0]
            peel_start_force = window_corrected[0]
            peel_start_idx = 0
        
        # Find peak
        peak_idx = np.argmax(window_corrected)
        peak_time = window_times[peak_idx]
        peak_force = window_corrected[peak_idx]
        peak_position = window_positions[peak_idx]
        
        # Find completion (return to baseline after peak)
        completion_idx = len(window_times) - 1  # Default to end
        post_peak_mask = np.arange(len(window_times)) > peak_idx
        
        if np.any(post_peak_mask):
            post_peak_corrected = window_corrected[post_peak_mask]
            post_peak_indices = np.arange(len(window_times))[post_peak_mask]
            
            # Find return to baseline (within 2x noise threshold)
            baseline_return_mask = np.abs(post_peak_corrected) < (2 * noise_threshold)
            
            if np.any(baseline_return_mask):
                baseline_indices = np.where(baseline_return_mask)[0]
                completion_idx = post_peak_indices[baseline_indices[0]]
                
                # Look for sustained return (3+ consecutive points)
                for i in range(len(baseline_indices) - 2):
                    if (baseline_indices[i+1] == baseline_indices[i] + 1 and 
                        baseline_indices[i+2] == baseline_indices[i] + 2):
                        completion_idx = post_peak_indices[baseline_indices[i]]
                        break
        
        completion_time = window_times[completion_idx]
        completion_force = window_corrected[completion_idx]
        
        # Calculate durations
        peel_duration = completion_time - detected_peel_start
        peak_to_completion = completion_time - peak_time
        time_to_peak = peak_time - detected_peel_start
        
        # Validation against expected
        start_difference = abs(detected_peel_start - event["expected_peel_start"])
        
        print(f"\n  TIMING RESULTS:")
        print(f"    Expected peel start: {event['expected_peel_start']:.1f}s")
        print(f"    Detected peel start: {detected_peel_start:.1f}s")
        print(f"    Start difference: {start_difference:.1f}s")
        print(f"    Peak time: {peak_time:.1f}s")
        print(f"    Completion time: {completion_time:.1f}s")
        
        print(f"\n  DURATION ANALYSIS:")
        print(f"    Time to peak: {time_to_peak:.2f}s")
        print(f"    Peak to completion: {peak_to_completion:.2f}s")
        print(f"    Total peel duration: {peel_duration:.2f}s")
        
        print(f"\n  FORCE ANALYSIS:")
        print(f"    Peel start force: {peel_start_force:.6f}N")
        print(f"    Peak force: {peak_force:.6f}N")
        print(f"    Completion force: {completion_force:.6f}N")
        
        print(f"\n  VALIDATION:")
        print(f"    Good start detection (<1s diff): {'✓' if start_difference < 1.0 else '✗'}")
        print(f"    Quick sawtooth drop (<0.5s): {'✓' if peak_to_completion < 0.5 else '✗'}")
        print(f"    Returns to baseline: {'✓' if abs(completion_force) < 2*noise_threshold else '✗'}")
    
    print(f"\n" + "=" * 50)
    print("KEY IMPROVEMENTS IMPLEMENTED:")
    print("✓ Post-separation baseline correction")
    print("✓ Peel initiation when force crosses corrected baseline")  
    print("✓ Completion when force returns to baseline")
    print("✓ Physics-based three-phase detection")
    print("✓ Noise-aware thresholds")
    
    print(f"\nNEXT STEPS:")
    print("- Review timing accuracy against your expectations")
    print("- Adjust noise threshold if needed")
    print("- Integrate into PeakForceLogger for real-time use")

if __name__ == "__main__":
    validate_baseline_correction()
