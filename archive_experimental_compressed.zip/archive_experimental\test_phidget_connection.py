#!/usr/bin/env python3
"""
Simple Phidget connection test script
"""

import time
from Phidget22.Devices.VoltageRatioInput import VoltageRatioInput
from Phidget22.PhidgetException import PhidgetException
from Phidget22.BridgeGain import BridgeGain

def test_phidget_connection():
    print("=== Phidget Connection Test ===")
    
    # Test each channel to find the correct one
    for channel in range(4):  # 4x Bridge Phidget has 4 channels (0-3)
        print(f"\nTesting Channel {channel}...")
        
        try:
            # Create VoltageRatioInput
            voltage_input = VoltageRatioInput()
            voltage_input.setHubPort(-1)  # Direct USB connection
            voltage_input.setChannel(channel)
            
            # Try to connect
            print(f"  Opening channel {channel} with 5s timeout...")
            voltage_input.openWaitForAttachment(5000)
            
            print(f"  ✓ Channel {channel} connected successfully!")
            
            # Test configuration
            try:
                print(f"  Setting bridge gain...")
                voltage_input.setBridgeGain(BridgeGain.BRIDGE_GAIN_1)
                
                print(f"  Setting data interval to 25ms...")
                voltage_input.setDataInterval(25)  # 40Hz
                
                print(f"  Enabling bridge...")
                voltage_input.setBridgeEnabled(True)
                
                print(f"  Reading voltage ratio...")
                time.sleep(0.5)  # Wait for stabilization
                
                voltage_ratio = voltage_input.getVoltageRatio()
                print(f"  Current voltage ratio: {voltage_ratio:.8f}")
                
                print(f"  ✓ Channel {channel} fully configured and working!")
                
            except Exception as e:
                print(f"  ⚠ Channel {channel} connected but configuration failed: {e}")
            
            # Clean up
            voltage_input.close()
            print(f"  Channel {channel} closed cleanly")
            
        except PhidgetException as ex:
            print(f"  ✗ Channel {channel} failed: {ex.description}")
        except Exception as e:
            print(f"  ✗ Channel {channel} error: {e}")
    
    print("\n=== Test Complete ===")

if __name__ == "__main__":
    test_phidget_connection()
